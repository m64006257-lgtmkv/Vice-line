# GTAVC_Unified_Fixed.py - الإصدار المصحح
import os
import sys
import json
import time
import threading
from enum import Enum
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

# ==================== فحص النظام ====================
def system_check():
    """فحص متطلبات النظام"""
    checks = []
    
    # 1. نظام التشغيل
    if sys.platform != "win32":
        checks.append("❌ يتطلب النظام Windows")
    
    # 2. إصدار Python
    if sys.version_info < (3, 8):
        checks.append(f"❌ يتطلب Python 3.8+ (لديك {sys.version_info.major}.{sys.version_info.minor})")
    
    # 3. المكتبات الأساسية
    try:
        import psutil
    except ImportError:
        checks.append("❌ مكتبة psutil غير مثبتة - قم بتشغيل: pip install psutil")
    
    return checks

# ==================== فئات الاحتياط المحسنة ====================
class AdvancedInjector:
    """نسخة احتياطية محسنة"""
    @staticmethod
    def find_gta_process():
        try:
            import psutil
            for proc in psutil.process_iter(['pid', 'name']):
                name = proc.info['name'].lower()
                if 'gta' in name or 'vice' in name:
                    return proc.info['pid'], proc.info['name']
        except:
            pass
        return None, None
    
    @staticmethod
    def inject_dll(pid, dll_path):
        print(f"[SIM] حقن DLL في العملية {pid}")
        return True  # محاكاة النجاح

class CPPController:
    """نسخة احتياطية محسنة"""
    def __init__(self, port=52525):
        self.port = port
        self.connected = False
    
    def connect(self):
        print(f"[SIM] الاتصال بمنفذ {self.port}")
        self.connected = True
        return True
    
    def disconnect(self):
        self.connected = False
    
    def initialize_core(self):
        return True
    
    def shutdown_core(self):
        return True
    
    def get_status(self):
        return {"status": "simulation", "players": 0}
    
    def create_remote_player(self, player_id, x, y, z):
        print(f"[SIM] إنشاء لاعب {player_id} في ({x}, {y}, {z})")
        return 0x1000  # عنوان محاكاة
    
    def update_remote_player(self, player_id, position, rotation):
        return True
    
    def get_local_player_position(self):
        return (100.0, 200.0, 10.0)  # موقع افتراضي

class GTAVCMemoryManager:
    """نسخة احتياطية محسنة"""
    def __init__(self):
        self.is_attached = False
    
    def attach_to_process(self):
        self.is_attached = True
        return True
    
    def get_player_position(self):
        return (0.0, 0.0, 0.0)
    
    def get_player_rotation(self):
        return (0.0, 0.0, 0.0)
    
    def detach(self):
        self.is_attached = False

# ==================== استيراد المكونات الحقيقية ====================
try:
    from AdvancedInjector import AdvancedInjector as RealAdvancedInjector
    ADVANCED_INJECTOR_AVAILABLE = True
    AdvancedInjector = RealAdvancedInjector
except ImportError:
    print("⚠ استخدام النسخة الاحتياطية لـ AdvancedInjector")
    ADVANCED_INJECTOR_AVAILABLE = False

try:
    from CPP_Controller import CPPController as RealCPPController
    CPP_CONTROLLER_AVAILABLE = True
    CPPController = RealCPPController
except ImportError:
    print("⚠ استخدام النسخة الاحتياطية لـ CPPController")
    CPP_CONTROLLER_AVAILABLE = False

try:
    from MemoryInjector import GTAVCMemoryManager as RealMemoryManager
    MEMORY_INJECTOR_AVAILABLE = True
    GTAVCMemoryManager = RealMemoryManager
except ImportError:
    print("⚠ استخدام النسخة الاحتياطية لـ MemoryManager")
    MEMORY_INJECTOR_AVAILABLE = False

# ==================== النظام الموحد المحسن ====================
class UnifiedMultiplayerSystem:
    """النظام الموحد - إصدار مصحح"""
    
    def __init__(self, mode="HYBRID"):
        self.mode = mode.upper()
        self.is_host = False
        self.running = False
        
        # المكونات
        self.injector = AdvancedInjector() if ADVANCED_INJECTOR_AVAILABLE else None
        self.cpp_controller = None
        self.memory_manager = None
        
        # حالة النظام
        self.players = {}
        self.local_player_id = os.getpid()
        self.game_pid = None
        
        # خيوط العمل
        self.threads = []
        
        # السجلات
        self.logs = []
        
    def log(self, message):
        """تسجيل رسالة"""
        timestamp = time.strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {message}"
        self.logs.append(log_entry)
        print(log_entry)
        
        # حفظ السجل
        if len(self.logs) > 100:
            self.save_logs()
    
    def save_logs(self):
        """حفظ السجلات"""
        try:
            with open("system_log.json", "w", encoding="utf-8") as f:
                json.dump({
                    "timestamp": time.time(),
                    "mode": self.mode,
                    "logs": self.logs[-50:]  # آخر 50 سجل
                }, f, indent=2, ensure_ascii=False)
        except:
            pass
    
    def initialize(self, as_host=True):
        """تهيئة النظام - إصدار مصحح"""
        self.log(f"بدء تهيئة النظام (الوضع: {self.mode}, الدور: {'Host' if as_host else 'Client'})")
        
        # 1. فحص النظام
        checks = system_check()
        if checks:
            for check in checks:
                self.log(check)
            return False
        
        self.is_host = as_host
        
        try:
            # 2. البحث عن اللعبة
            self.log("البحث عن GTA Vice City...")
            pid, name = self.injector.find_gta_process() if self.injector else (None, None)
            
            if not pid:
                # بحث يدوي
                try:
                    import psutil
                    for proc in psutil.process_iter(['pid', 'name']):
                        pname = proc.info['name'].lower()
                        if any(x in pname for x in ['gta', 'vice', 'vc']):
                            pid, name = proc.info['pid'], proc.info['name']
                            break
                except:
                    pass
            
            if not pid:
                self.log("❌ لم يتم العثور على GTA Vice City")
                return False
            
            self.game_pid = pid
            self.log(f"✅ تم العثور على {name} (PID: {pid})")
            
            # 3. وضع HYBRID أو CPP_ONLY
            if self.mode in ["HYBRID", "CPP_ONLY"]:
                if not self._initialize_cpp_core():
                    if self.mode == "CPP_ONLY":
                        self.log("❌ فشل تهيئة نواة C++")
                        return False
                    else:
                        self.log("⚠ العودة للوضع STANDALONE")
                        self.mode = "STANDALONE"
            
            # 4. وضع STANDALONE أو HYBRID
            if self.mode in ["STANDALONE", "HYBRID"]:
                self._initialize_memory_manager()
            
            # 5. بدء الأنظمة
            self._start_subsystems()
            
            self.running = True
            self.log("✅ تم تهيئة النظام بنجاح")
            return True
            
        except Exception as e:
            self.log(f"❌ فشل التهيئة: {e}")
            import traceback
            self.log(traceback.format_exc())
            return False
    
    def _initialize_cpp_core(self):
        """تهيئة نواة C++ - إصدار مصحح"""
        self.log("تهيئة نواة C++...")
        
        if not CPP_CONTROLLER_AVAILABLE:
            self.log("❌ متحكم C++ غير متوفر")
            return False
        
        dll_name = "MultiplayerCore.dll"
        
        # البحث عن DLL
        for path in [".", "system", os.getcwd()]:
            dll_path = os.path.join(path, dll_name)
            if os.path.exists(dll_path):
                self.log(f"✅ تم العثور على {dll_name} في {dll_path}")
                
                # الحقن
                if self.injector and self.game_pid:
                    if not self.injector.inject_dll(self.game_pid, dll_path):
                        self.log("❌ فشل حقن DLL")
                        return False
                
                # انتظار تحميل DLL
                time.sleep(3)
                
                # الاتصال
                self.cpp_controller = CPPController()
                if not self.cpp_controller.connect():
                    self.log("❌ فشل الاتصال بمتحكم C++")
                    return False
                
                # التهيئة
                if not self.cpp_controller.initialize_core():
                    self.log("❌ فشل تهيئة نواة C++")
                    return False
                
                self.log("✅ تم تهيئة نواة C++ بنجاح")
                return True
        
        self.log(f"❌ لم يتم العثور على {dll_name}")
        return False
    
    def _initialize_memory_manager(self):
        """تهيئة مدير الذاكرة"""
        self.log("تهيئة مدير الذاكرة...")
        
        if not MEMORY_INJECTOR_AVAILABLE:
            self.log("❌ مدير الذاكرة غير متوفر")
            return False
        
        self.memory_manager = GTAVCMemoryManager()
        if not self.memory_manager.attach_to_process():
            self.log("❌ فشل الاتصال بعملية اللعبة")
            return False
        
        self.log("✅ تم تهيئة مدير الذاكرة")
        return True
    
    def _start_subsystems(self):
        """بدء الأنظمة الفرعية"""
        self.log("بدء الأنظمة الفرعية...")
        
        # خيط المزامنة
        sync_thread = threading.Thread(target=self._sync_loop, daemon=True)
        sync_thread.start()
        self.threads.append(sync_thread)
        
        # خيط المراقبة
        monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        monitor_thread.start()
        self.threads.append(monitor_thread)
    
    def _sync_loop(self):
        """حلقة المزامنة"""
        self.log("بدء حلقة المزامنة...")
        
        while self.running:
            try:
                # تحديث اللاعب المحلي
                if self.local_player_id not in self.players:
                    self.players[self.local_player_id] = {
                        "id": self.local_player_id,
                        "name": "Local Player",
                        "position": (0, 0, 0),
                        "last_update": time.time(),
                        "is_local": True
                    }
                
                # قراءة الموقع
                if self.mode == "CPP_ONLY" and self.cpp_controller:
                    pos = self.cpp_controller.get_local_player_position()
                elif self.memory_manager and self.memory_manager.is_attached:
                    pos = self.memory_manager.get_player_position()
                else:
                    pos = (100.0, 200.0, 10.0)
                
                self.players[self.local_player_id]["position"] = pos
                self.players[self.local_player_id]["last_update"] = time.time()
                
                time.sleep(0.05)  # 20Hz
                
            except Exception as e:
                self.log(f"خطأ في المزامنة: {e}")
                time.sleep(1)
    
    def _monitor_loop(self):
        """حلقة المراقبة"""
        while self.running:
            try:
                # مراقبة حالة النظام
                player_count = len(self.players)
                if player_count > 0:
                    self.log(f"اللاعبون النشطون: {player_count}")
                
                time.sleep(5)
                
            except:
                time.sleep(5)
    
    def create_remote_player(self, player_id, name, position):
        """إنشاء لاعب عن بعد - إصدار مصحح"""
        self.log(f"إنشاء لاعب {name} (ID: {player_id})...")
        
        try:
            # في وضع C++
            if self.mode in ["CPP_ONLY", "HYBRID"] and self.cpp_controller:
                addr = self.cpp_controller.create_remote_player(player_id, *position)
                if addr:
                    self.players[player_id] = {
                        "id": player_id,
                        "name": name,
                        "address": addr,
                        "position": position,
                        "last_update": time.time()
                    }
                    return True
            
            # في وضع Python
            if self.mode in ["STANDALONE", "HYBRID"] and self.memory_manager:
                try:
                    if hasattr(self.memory_manager, 'create_remote_player'):
                        slot, addr = self.memory_manager.create_remote_player(player_id, position)
                        if addr:
                            self.players[player_id] = {
                                "id": player_id,
                                "name": name,
                                "address": addr,
                                "position": position,
                                "last_update": time.time()
                            }
                            return True
                except AttributeError:
                    pass
            
            # المحاكاة
            self.players[player_id] = {
                "id": player_id,
                "name": name,
                "address": 0,
                "position": position,
                "last_update": time.time()
            }
            
            self.log(f"✅ تم إنشاء لاعب {name}")
            return True
            
        except Exception as e:
            self.log(f"❌ فشل إنشاء لاعب: {e}")
            return False
    
    def shutdown(self):
        """إيقاف النظام - إصدار مصحح"""
        self.log("إيقاف النظام...")
        
        self.running = False
        
        # انتظار الخيوط
        for thread in self.threads:
            if thread.is_alive():
                thread.join(timeout=2)
        
        # إيقاف C++
        if self.cpp_controller:
            try:
                self.cpp_controller.shutdown_core()
                self.cpp_controller.disconnect()
            except:
                pass
        
        # إيقاف الذاكرة
        if self.memory_manager:
            try:
                self.memory_manager.detach()
            except:
                pass
        
        self.log("✅ تم إيقاف النظام")
        self.save_logs()
    
    def get_status(self):
        """الحصول على حالة النظام"""
        return {
            "mode": self.mode,
            "running": self.running,
            "is_host": self.is_host,
            "game_pid": self.game_pid,
            "player_count": len(self.players),
            "logs_count": len(self.logs),
            "last_update": time.time()
        }

# ==================== الواجهة الرئيسية ====================
def main():
    """الواجهة الرئيسية - إصدار مصحح"""
    
    print("=" * 60)
    print("GTA Vice City - Unified Multiplayer System")
    print("Version: 2.0 (Fixed and Optimized)")
    print("=" * 60)
    print()
    
    # فحص النظام
    checks = system_check()
    if checks:
        print("❌ مشاكل في النظام:")
        for check in checks:
            print(f"  {check}")
        print()
        input("اضغط Enter للخروج...")
        return
    
    print("✅ النظام جاهز للتشغيل")
    print()
    
    # اختيار الوضع
    print("اختر وضع التشغيل:")
    print("1. HYBRID - Python + C++ (موصى به)")
    print("2. STANDALONE - Python فقط")
    print("3. CPP_ONLY - C++ فقط")
    print()
    
    choice = input("الاختيار [1-3] (افتراضي 1): ").strip()
    
    mode_map = {"1": "HYBRID", "2": "STANDALONE", "3": "CPP_ONLY"}
    mode = mode_map.get(choice, "HYBRID")
    
    # اختيار الدور
    print()
    print("اختر الدور:")
    print("1. Host - إنشاء غرفة")
    print("2. Client - الانضمام لغرفة")
    print()
    
    role = input("الاختيار [1-2] (افتراضي 1): ").strip()
    is_host = (role != "2")
    
    # إنشاء النظام
    system = UnifiedMultiplayerSystem(mode)
    
    # التهيئة
    if system.initialize(is_host):
        print()
        print("✅ النظام جاهز!")
        print("الأوامر المتاحة:")
        print("  status - عرض حالة النظام")
        print("  players - عرض اللاعبين")
        print("  create - إنشاء لاعب تجريبي")
        print("  logs - عرض السجلات")
        print("  exit - الخروج")
        print()
        
        while True:
            cmd = input("> ").strip().lower()
            
            if cmd == "exit":
                break
            elif cmd == "status":
                status = system.get_status()
                print(f"الوضع: {status['mode']}")
                print(f"الحالة: {'نشط' if status['running'] else 'متوقف'}")
                print(f"الدور: {'Host' if status['is_host'] else 'Client'}")
                print(f"عدد اللاعبين: {status['player_count']}")
            elif cmd == "players":
                for player_id, info in system.players.items():
                    print(f"  {info['name']} (ID: {player_id})")
                    print(f"    الموقع: {info['position']}")
            elif cmd == "create":
                system.create_remote_player(9999, "Test Player", (100, 200, 10))
            elif cmd == "logs":
                for log in system.logs[-10:]:
                    print(log)
            else:
                print("❌ أمر غير معروف")
        
        # الإيقاف
        system.shutdown()
    else:
        print("❌ فشل تهيئة النظام")

if __name__ == "__main__":
    main()