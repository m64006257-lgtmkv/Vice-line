# 1. تثبيت المتطلبات فقط
pip install psutil

# 2. نسخ DLL جاهز إلى مجلد dist
# 3. التشغيل
python GTAVC_Unified_System.py