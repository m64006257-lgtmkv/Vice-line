// MultiplayerCore_Unified.cpp - الإصدار الموحد والمصحح
#include <windows.h>
#include <winsock2.h>
#include <stdio.h>
#include <vector>
#include <thread>
#include <atomic>
#include <mutex>
#include <map>

#pragma comment(lib, "ws2_32.lib")

// ==================== هيكل البيانات المشترك ====================
#pragma pack(push, 1)
struct NetworkPacket {
    BYTE packetType;
    DWORD playerId;
    float position[3];
    float rotation[3];
    DWORD timestamp;
};
#pragma pack(pop)

// ==================== مدير الذاكرة ====================
class MemoryManager {
private:
    HANDLE hProcess;
    DWORD processId;
    DWORD baseAddress;
    std::mutex memoryMutex;
    
public:
    MemoryManager() : hProcess(NULL), processId(0), baseAddress(0) {}
    
    BOOL Attach() {
        HWND hwnd = FindWindowA(NULL, "GTA: Vice City");
        if (!hwnd) return FALSE;
        
        GetWindowThreadProcessId(hwnd, &processId);
        hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, processId);
        
        if (!hProcess) return FALSE;
        
        HMODULE modules[1];
        DWORD needed;
        if (EnumProcessModules(hProcess, modules, sizeof(modules), &needed)) {
            baseAddress = (DWORD)modules[0];
        }
        
        return TRUE;
    }
    
    BOOL Read(DWORD address, LPVOID buffer, SIZE_T size) {
        std::lock_guard<std::mutex> lock(memoryMutex);
        SIZE_T bytesRead;
        return ReadProcessMemory(hProcess, (LPCVOID)address, buffer, size, &bytesRead);
    }
    
    BOOL Write(DWORD address, LPCVOID buffer, SIZE_T size) {
        std::lock_guard<std::mutex> lock(memoryMutex);
        SIZE_T bytesWritten;
        return WriteProcessMemory(hProcess, (LPVOID)address, buffer, size, &bytesWritten);
    }
    
    void Detach() {
        if (hProcess) CloseHandle(hProcess);
        hProcess = NULL;
    }
};

// ==================== النظام الرئيسي ====================
class MultiplayerCore {
private:
    MemoryManager memory;
    std::atomic<bool> running;
    std::thread networkThread;
    SOCKET controlSocket;
    
public:
    MultiplayerCore() : running(false), controlSocket(INVALID_SOCKET) {}
    
    BOOL Initialize(BOOL isHost) {
        if (!memory.Attach()) {
            printf("Failed to attach to GTA VC\n");
            return FALSE;
        }
        
        // بدء خيط الشبكة
        running = true;
        networkThread = std::thread(&MultiplayerCore::NetworkLoop, this);
        
        // بدء خادم التحكم
        if (!StartControlServer()) {
            printf("Failed to start control server\n");
            return FALSE;
        }
        
        printf("MultiplayerCore initialized successfully\n");
        return TRUE;
    }
    
    void Shutdown() {
        running = false;
        
        if (networkThread.joinable()) {
            networkThread.join();
        }
        
        if (controlSocket != INVALID_SOCKET) {
            closesocket(controlSocket);
        }
        
        memory.Detach();
        WSACleanup();
    }
    
    BOOL StartControlServer() {
        WSADATA wsaData;
        if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
            return FALSE;
        }
        
        controlSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (controlSocket == INVALID_SOCKET) {
            return FALSE;
        }
        
        sockaddr_in serverAddr;
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_port = htons(52525);
        serverAddr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        
        if (bind(controlSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
            closesocket(controlSocket);
            return FALSE;
        }
        
        if (listen(controlSocket, 1) == SOCKET_ERROR) {
            closesocket(controlSocket);
            return FALSE;
        }
        
        // بدء thread للتحكم
        std::thread(&MultiplayerCore::ControlLoop, this).detach();
        
        return TRUE;
    }
    
    void NetworkLoop() {
        // حلقة الشبكة الأساسية
        while (running) {
            Sleep(50); // 20Hz
        }
    }
    
    void ControlLoop() {
        while (running) {
            sockaddr_in clientAddr;
            int addrLen = sizeof(clientAddr);
            SOCKET client = accept(controlSocket, (sockaddr*)&clientAddr, &addrLen);
            
            if (client != INVALID_SOCKET) {
                HandleControlClient(client);
                closesocket(client);
            }
        }
    }
    
    void HandleControlClient(SOCKET client) {
        char buffer[1024];
        int bytes = recv(client, buffer, sizeof(buffer), 0);
        
        if (bytes > 0) {
            // معالجة الأوامر البسيطة
            const char* response = "OK";
            send(client, response, strlen(response), 0);
        }
    }
};

// ==================== المتغيرات العالمية ====================
static MultiplayerCore* g_Core = NULL;

// ==================== دوال التصدير ====================
extern "C" __declspec(dllexport) BOOL InitializeMultiplayer(BOOL isHost) {
    if (g_Core) return TRUE;
    
    g_Core = new MultiplayerCore();
    return g_Core->Initialize(isHost);
}

extern "C" __declspec(dllexport) void ShutdownMultiplayer() {
    if (g_Core) {
        g_Core->Shutdown();
        delete g_Core;
        g_Core = NULL;
    }
}

extern "C" __declspec(dllexport) BOOL IsMultiplayerActive() {
    return g_Core != NULL;
}

// ==================== نقطة دخول DLL ====================
BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID lpReserved) {
    switch (reason) {
        case DLL_PROCESS_ATTACH:
            // يمكن ترك التهيئة لاحقاً بواسطة Python
            break;
        case DLL_PROCESS_DETACH:
            ShutdownMultiplayer();
            break;
    }
    return TRUE;
}