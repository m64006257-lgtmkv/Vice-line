# IntegratedSystem.py - النظام المتكامل مع الشبكة
import os
import sys
import time
import threading
from enum import Enum
from typing import Dict, List, Optional, Tuple
import json

# استيراد نظام الشبكة
try:
    from NetworkManager import NetworkManager, PacketType, NetworkPacket
    NETWORK_AVAILABLE = True
except ImportError:
    print("⚠ NetworkManager not found, network features disabled")
    NETWORK_AVAILABLE = False

class GameMode(Enum):
    SINGLE_PLAYER = "single"
    LAN_HOST = "lan_host"
    LAN_CLIENT = "lan_client"
    ONLINE = "online"

class IntegratedGameSystem:
    """النظام المتكامل مع الشبكة"""
    
    def __init__(self):
        self.game_mode = GameMode.SINGLE_PLAYER
        self.running = False
        
        # نظام الشبكة
        self.network = NetworkManager() if NETWORK_AVAILABLE else None
        
        # اللاعبون
        self.local_player = None
        self.remote_players = {}  # player_id -> player_data
        
        # المزامنة
        self.sync_interval = 0.05  # 20Hz
        self.network_sync_interval = 0.1  # 10Hz
        self.last_sync_time = 0
        
        # الخيوط
        self.sync_thread = None
        self.network_thread = None
        
        # السجلات
        self.network_log = []
        
    def initialize(self, mode: GameMode, player_name: str = None):
        """تهيئة النظام"""
        print(f"🚀 Initializing system in {mode.value} mode...")
        
        self.game_mode = mode
        self.running = True
        
        # إعداد اللاعب المحلي
        self.local_player = {
            'id': os.getpid(),
            'name': player_name or f"Player_{os.getpid()}",
            'position': (0.0, 0.0, 0.0),
            'rotation': (0.0, 0.0, 0.0),
            'health': 100,
            'armor': 0,
            'vehicle': None
        }
        
        # بدء النظام حسب الوضع
        if mode == GameMode.LAN_HOST:
            self._start_as_host(player_name)
        elif mode == GameMode.LAN_CLIENT:
            self._start_as_client(player_name)
        elif mode == GameMode.SINGLE_PLAYER:
            self._start_single_player()
        elif mode == GameMode.ONLINE:
            self._start_online()
        
        # بدء خيوط المزامنة
        self._start_sync_threads()
        
        print(f"✅ System initialized in {mode.value} mode")
        return True
    
    def _start_as_host(self, player_name: str):
        """بدء كمضيف LAN"""
        if not self.network:
            print("❌ Network system not available")
            return False
        
        if self.network.start_host(player_name):
            print("🎮 Host started, waiting for players...")
            
            # تسجيل ردود الفعل للشبكة
            self.network.register_callback('player_join', self._on_player_join)
            self.network.register_callback('player_leave', self._on_player_leave)
            self.network.register_callback('position_update', self._on_position_update)
            self.network.register_callback('chat_message', self._on_chat_message)
            
            return True
        
        return False
    
    def _start_as_client(self, player_name: str):
        """بدء كعميل LAN"""
        if not self.network:
            print("❌ Network system not available")
            return False
        
        # اكتشاف الخوادم أولاً
        print("🔍 Discovering LAN servers...")
        servers = self.network.discover_servers(3.0)
        
        if not servers:
            print("❌ No LAN servers found")
            return False
        
        # عرض الخوادم المكتشفة
        print(f"Found {len(servers)} servers:")
        for i, server in enumerate(servers, 1):
            print(f"{i}. {server['name']} ({server['players']}/{server['max_players']})")
        
        # اختيار السيرفر
        try:
            choice = int(input("Select server: ")) - 1
            if 0 <= choice < len(servers):
                server = servers[choice]
                
                if self.network.connect_to_server(server['ip'], server['port'], player_name):
                    print(f"✅ Connected to {server['name']}")
                    
                    # تسجيل ردود الفعل
                    self.network.register_callback('connected', self._on_connected)
                    self.network.register_callback('disconnected', self._on_disconnected)
                    self.network.register_callback('player_join', self._on_player_join)
                    self.network.register_callback('player_leave', self._on_player_leave)
                    self.network.register_callback('position_update', self._on_position_update)
                    self.network.register_callback('chat_message', self._on_chat_message)
                    
                    return True
            else:
                print("❌ Invalid choice")
        except:
            print("❌ Invalid input")
        
        return False
    
    def _start_single_player(self):
        """بدء في وضع اللاعب الواحد"""
        print("🎮 Single player mode activated")
        return True
    
    def _start_online(self):
        """بدء في وضع الأونلاين"""
        print("🌐 Online mode (not implemented yet)")
        return False
    
    def _start_sync_threads(self):
        """بدء خيوط المزامنة"""
        # خيط مزامنة اللعبة
        self.sync_thread = threading.Thread(target=self._game_sync_loop, daemon=True)
        self.sync_thread.start()
        
        # خيط مزامنة الشبكة
        if self.network and self.game_mode in [GameMode.LAN_HOST, GameMode.LAN_CLIENT]:
            self.network_thread = threading.Thread(target=self._network_sync_loop, daemon=True)
            self.network_thread.start()
    
    def _game_sync_loop(self):
        """حلقة مزامنة اللعبة"""
        while self.running:
            try:
                # قراءة بيانات اللاعب المحلي من الذاكرة
                player_data = self._read_local_player_data()
                
                if player_data:
                    # تحديث بيانات اللاعب المحلي
                    self.local_player.update(player_data)
                    
                    # إرسال تحديث الشبكة إذا لزم الأمر
                    current_time = time.time()
                    if current_time - self.last_sync_time >= self.network_sync_interval:
                        if self.network and self.network.is_connected():
                            self.network.send_position(
                                self.local_player['position'],
                                self.local_player['rotation'],
                                self.local_player['health'],
                                self.local_player['armor']
                            )
                            self.last_sync_time = current_time
                
                time.sleep(self.sync_interval)
                
            except Exception as e:
                print(f"Game sync error: {e}")
                time.sleep(1)
    
    def _network_sync_loop(self):
        """حلقة مزامنة الشبكة"""
        while self.running:
            try:
                # تحديث حالة الشبكة
                if self.network:
                    # إرسال ping للحفاظ على الاتصال
                    pass
                
                time.sleep(1.0)
                
            except Exception as e:
                print(f"Network sync error: {e}")
                time.sleep(1)
    
    def _read_local_player_data(self) -> Optional[Dict]:
        """قراءة بيانات اللاعب المحلي من الذاكرة"""
        # هذه الدالة ستقرأ من الذاكرة الحقيقية
        # حالياً، نعيد بيانات وهمية للاختبار
        import random
        
        return {
            'position': (
                self.local_player['position'][0] + random.uniform(-1, 1),
                self.local_player['position'][1] + random.uniform(-1, 1),
                self.local_player['position'][2]
            ),
            'rotation': (
                self.local_player['rotation'][0],
                self.local_player['rotation'][1],
                self.local_player['rotation'][2] + random.uniform(-5, 5)
            ),
            'health': max(0, min(100, self.local_player['health'] + random.randint(-1, 1))),
            'armor': self.local_player['armor']
        }
    
    # ==================== معالجات أحداث الشبكة ====================
    
    def _on_connected(self, server_ip: str, port: int):
        """عند الاتصال بالخادم"""
        print(f"✅ Connected to {server_ip}:{port}")
        self._log_network(f"Connected to {server_ip}:{port}")
    
    def _on_disconnected(self):
        """عند قطع الاتصال"""
        print("❌ Disconnected from server")
        self._log_network("Disconnected from server")
        self.running = False
    
    def _on_player_join(self, player_id: int, player_name: str, address=None):
        """عند انضمام لاعب جديد"""
        if player_id == self.local_player['id']:
            return
        
        print(f"👤 {player_name} joined the game")
        self._log_network(f"Player {player_name} joined")
        
        # إضافة اللاعب الجديد
        self.remote_players[player_id] = {
            'id': player_id,
            'name': player_name,
            'address': address,
            'position': (0.0, 0.0, 0.0),
            'rotation': (0.0, 0.0, 0.0),
            'health': 100,
            'armor': 0,
            'last_update': time.time()
        }
        
        # إنشاء كائن اللاعب في الذاكرة
        self._create_remote_player_in_memory(player_id, player_name)
    
    def _on_player_leave(self, player_id: int, player_name: str):
        """عند مغادرة لاعب"""
        print(f"👤 {player_name} left the game")
        self._log_network(f"Player {player_name} left")
        
        # إزالة اللاعب
        if player_id in self.remote_players:
            # تدمير كائن اللاعب من الذاكرة
            self._destroy_remote_player_in_memory(player_id)
            del self.remote_players[player_id]
    
    def _on_position_update(self, player_id: int, position: Tuple, rotation: Tuple, 
                           health: int, armor: int):
        """عند تحديث موقع لاعب"""
        if player_id == self.local_player['id']:
            return
        
        if player_id in self.remote_players:
            player = self.remote_players[player_id]
            player['position'] = position
            player['rotation'] = rotation
            player['health'] = health
            player['armor'] = armor
            player['last_update'] = time.time()
            
            # تحديث كائن اللاعب في الذاكرة
            self._update_remote_player_in_memory(player_id, position, rotation)
    
    def _on_chat_message(self, player_id: int, player_name: str, message: str):
        """عند استقبال رسالة دردشة"""
        if player_id == self.local_player['id']:
            return
        
        print(f"[{player_name}]: {message}")
        self._log_network(f"Chat from {player_name}: {message}")
    
    def _create_remote_player_in_memory(self, player_id: int, player_name: str):
        """إنشاء كائن لاعب في الذاكرة"""
        # هذه الدالة ستتفاعل مع مدير الذاكرة C++
        print(f"[MEM] Creating remote player {player_name} (ID: {player_id})")
    
    def _update_remote_player_in_memory(self, player_id: int, position: Tuple, rotation: Tuple):
        """تحديث كائن لاعب في الذاكرة"""
        # هذه الدالة ستتفاعل مع مدير الذاكرة C++
        print(f"[MEM] Updating player {player_id} position")
    
    def _destroy_remote_player_in_memory(self, player_id: int):
        """تدمير كائن لاعب من الذاكرة"""
        # هذه الدالة ستتفاعل مع مدير الذاكرة C++
        print(f"[MEM] Destroying remote player {player_id}")
    
    def _log_network(self, message: str):
        """تسجيل رسالة شبكة"""
        timestamp = time.strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {message}"
        self.network_log.append(log_entry)
        
        # حفظ السجل
        if len(self.network_log) > 100:
            self._save_network_log()
    
    def _save_network_log(self):
        """حفظ سجل الشبكة"""
        try:
            with open("network_log.json", "w", encoding="utf-8") as f:
                json.dump({
                    'timestamp': time.time(),
                    'mode': self.game_mode.value,
                    'logs': self.network_log[-50:]
                }, f, indent=2, ensure_ascii=False)
        except:
            pass
    
    def send_chat_message(self, message: str):
        """إرسال رسالة دردشة"""
        if self.network and self.network.is_connected():
            self.network.send_chat(message)
            print(f"[{self.local_player['name']}]: {message}")
    
    def get_player_list(self) -> List[Dict]:
        """الحصول على قائمة اللاعبين"""
        players = []
        
        # اللاعب المحلي
        players.append({
            'id': self.local_player['id'],
            'name': self.local_player['name'],
            'is_local': True,
            'position': self.local_player['position'],
            'health': self.local_player['health']
        })
        
        # اللاعبين عن بعد
        for player in self.remote_players.values():
            players.append({
                'id': player['id'],
                'name': player['name'],
                'is_local': False,
                'position': player['position'],
                'health': player['health'],
                'last_update': player['last_update']
            })
        
        return players
    
    def discover_servers(self) -> List[Dict]:
        """اكتشاف خوادم LAN"""
        if self.network:
            return self.network.discover_servers()
        return []
    
    def shutdown(self):
        """إيقاف النظام"""
        print("🛑 Shutting down system...")
        
        self.running = False
        
        # إيقاف الشبكة
        if self.network:
            self.network.disconnect()
        
        # انتظار إنهاء الخيوط
        if self.sync_thread and self.sync_thread.is_alive():
            self.sync_thread.join(timeout=2)
        
        if self.network_thread and self.network_thread.is_alive():
            self.network_thread.join(timeout=2)
        
        # حفظ السجلات
        self._save_network_log()
        
        print("✅ System shutdown complete")

# ==================== الواجهة الرئيسية ====================
def main():
    """الواجهة الرئيسية"""
    print("=" * 60)
    print("🎮 GTA Vice City - Integrated Multiplayer System")
    print("🌐 Complete Network System with P2P Support")
    print("=" * 60)
    
    system = IntegratedGameSystem()
    
    print("\nSelect game mode:")
    print("1. Single Player")
    print("2. LAN Host (Create Game)")
    print("3. LAN Client (Join Game)")
    print("4. Online (Coming Soon)")
    
    choice = input("\nChoice [1-3]: ").strip()
    
    player_name = input("Enter your name: ").strip() or f"Player_{os.getpid()}"
    
    if choice == "1":
        mode = GameMode.SINGLE_PLAYER
    elif choice == "2":
        mode = GameMode.LAN_HOST
    elif choice == "3":
        mode = GameMode.LAN_CLIENT
    elif choice == "4":
        mode = GameMode.ONLINE
    else:
        print("❌ Invalid choice, using Single Player")
        mode = GameMode.SINGLE_PLAYER
    
    # تهيئة النظام
    if system.initialize(mode, player_name):
        print(f"\n✅ System ready as {player_name}")
        print("Commands: chat <message>, players, servers, exit")
        
        # حلقة الأوامر
        while system.running:
            try:
                cmd = input(f"{player_name}> ").strip().lower()
                
                if cmd.startswith("chat "):
                    message = cmd[5:]
                    system.send_chat_message(message)
                
                elif cmd == "players":
                    players = system.get_player_list()
                    print(f"\nPlayers ({len(players)}):")
                    for player in players:
                        status = "LOCAL" if player['is_local'] else "REMOTE"
                        print(f"  {player['name']} [{status}] - HP: {player['health']}")
                
                elif cmd == "servers" and mode == GameMode.LAN_CLIENT:
                    servers = system.discover_servers()
                    if servers:
                        print(f"\nAvailable servers ({len(servers)}):")
                        for server in servers:
                            print(f"  {server['name']} ({server['players']}/{server['max_players']})")
                    else:
                        print("No servers found")
                
                elif cmd == "exit":
                    break
                
                else:
                    print("❌ Unknown command")
                    
            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"❌ Error: {e}")
        
        # إيقاف النظام
        system.shutdown()
    else:
        print("❌ Failed to initialize system")

if __name__ == "__main__":
    main()