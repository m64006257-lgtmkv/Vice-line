# NetworkManager.py - نظام شبكة Python متكامل
import socket
import struct
import threading
import time
import json
import select
from enum import IntEnum
from typing import List, Dict, Optional, Tuple, Callable
from dataclasses import dataclass
import pickle

# تعريفات الشبكة
NETWORK_PORT = 5192
BROADCAST_PORT = 9999
MAX_PACKET_SIZE = 1024
CONNECT_TIMEOUT = 5.0
HEARTBEAT_INTERVAL = 3.0

# أنواع الحزم
class PacketType(IntEnum):
    HANDSHAKE = 0x01
    POSITION_UPDATE = 0x02
    PLAYER_JOIN = 0x03
    PLAYER_LEAVE = 0x04
    CHAT_MESSAGE = 0x05
    VEHICLE_UPDATE = 0x06
    PING = 0x07
    GAME_STATE = 0x08

@dataclass
class NetworkPlayer:
    """لاعب في الشبكة"""
    player_id: int
    name: str
    address: tuple  # (ip, port)
    socket: Optional[socket.socket]
    last_seen: float
    is_local: bool = False
    position: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    rotation: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    health: int = 100
    armor: int = 0

@dataclass
class NetworkPacket:
    """حزمة شبكة"""
    packet_type: int
    sender_id: int
    sequence: int
    timestamp: float
    data: bytes
    
    def to_bytes(self) -> bytes:
        """تحويل الحزمة إلى بايتات"""
        header = struct.pack('<BIII', 
                           self.packet_type,
                           self.sender_id,
                           self.sequence,
                           int(self.timestamp * 1000))
        return header + self.data
    
    @classmethod
    def from_bytes(cls, data: bytes) -> Optional['NetworkPacket']:
        """إنشاء حزمة من البايتات"""
        if len(data) < 13:  # 1 + 4 + 4 + 4
            return None
        
        try:
            packet_type, sender_id, sequence, timestamp = struct.unpack('<BIII', data[:13])
            packet_data = data[13:] if len(data) > 13 else b''
            
            return cls(
                packet_type=packet_type,
                sender_id=sender_id,
                sequence=sequence,
                timestamp=timestamp / 1000.0,
                data=packet_data
            )
        except:
            return None

class LANServer:
    """خادم LAN"""
    
    def __init__(self, player_id: int, player_name: str, max_players: int = 16):
        self.player_id = player_id
        self.player_name = player_name
        self.max_players = max_players
        
        self.running = False
        self.server_socket = None
        self.broadcast_socket = None
        
        self.players: Dict[int, NetworkPlayer] = {}
        self.players_lock = threading.RLock()
        
        self.sequence_number = 0
        
        # خيوط العمل
        self.accept_thread = None
        self.broadcast_thread = None
        self.heartbeat_thread = None
        
        # استدعاءات رد الفعل
        self.on_player_join: Optional[Callable] = None
        self.on_player_leave: Optional[Callable] = None
        self.on_position_update: Optional[Callable] = None
        self.on_chat_message: Optional[Callable] = None
    
    def start(self, port: int = NETWORK_PORT) -> bool:
        """بدء الخادم"""
        try:
            # إنشاء مقبس الخادم
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            
            # الربط
            self.server_socket.bind(('0.0.0.0', port))
            self.server_socket.listen(10)
            self.server_socket.settimeout(1.0)
            
            # إنشاء مقبس البث
            self.broadcast_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.broadcast_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            
            self.running = True
            
            # إضافة اللاعب المحلي
            local_player = NetworkPlayer(
                player_id=self.player_id,
                name=self.player_name,
                address=('127.0.0.1', port),
                socket=None,
                last_seen=time.time(),
                is_local=True
            )
            
            with self.players_lock:
                self.players[self.player_id] = local_player
            
            # بدء الخيوط
            self.accept_thread = threading.Thread(target=self._accept_connections, daemon=True)
            self.broadcast_thread = threading.Thread(target=self._broadcast_presence, daemon=True)
            self.heartbeat_thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
            
            self.accept_thread.start()
            self.broadcast_thread.start()
            self.heartbeat_thread.start()
            
            print(f"✅ LAN server started on port {port}")
            return True
            
        except Exception as e:
            print(f"❌ Failed to start server: {e}")
            self.stop()
            return False
    
    def stop(self):
        """إيقاف الخادم"""
        self.running = False
        
        # إغلاق المقابس
        if self.server_socket:
            self.server_socket.close()
        
        if self.broadcast_socket:
            self.broadcast_socket.close()
        
        # فصل جميع اللاعبين
        with self.players_lock:
            for player_id in list(self.players.keys()):
                if not self.players[player_id].is_local:
                    self._disconnect_player(player_id)
            
            self.players.clear()
        
        print("✅ LAN server stopped")
    
    def send_to_all(self, packet: NetworkPacket, exclude_local: bool = False):
        """إرسال حزمة لجميع اللاعبين"""
        with self.players_lock:
            for player_id, player in self.players.items():
                if exclude_local and player.is_local:
                    continue
                
                if player.socket:
                    try:
                        player.socket.sendall(packet.to_bytes())
                    except:
                        self._disconnect_player(player_id)
    
    def send_to_player(self, player_id: int, packet: NetworkPacket) -> bool:
        """إرسال حزمة للاعب معين"""
        with self.players_lock:
            if player_id in self.players:
                player = self.players[player_id]
                if player.socket:
                    try:
                        player.socket.sendall(packet.to_bytes())
                        return True
                    except:
                        self._disconnect_player(player_id)
        return False
    
    def broadcast_position(self, position: Tuple[float, float, float], 
                          rotation: Tuple[float, float, float],
                          health: int = 100, armor: int = 0):
        """بث موقع اللاعب المحلي"""
        # تحضير بيانات الموقع
        position_data = struct.pack('<ffffffHH',
                                  position[0], position[1], position[2],
                                  rotation[0], rotation[1], rotation[2],
                                  health, armor)
        
        # إنشاء الحزمة
        packet = NetworkPacket(
            packet_type=PacketType.POSITION_UPDATE,
            sender_id=self.player_id,
            sequence=self.sequence_number,
            timestamp=time.time(),
            data=position_data
        )
        
        self.sequence_number += 1
        
        # الإرسال للجميع
        self.send_to_all(packet, exclude_local=True)
    
    def broadcast_chat(self, message: str):
        """بث رسالة دردشة"""
        # التحقق من طول الرسالة
        if len(message) > 200:
            message = message[:200]
        
        # إنشاء الحزمة
        packet = NetworkPacket(
            packet_type=PacketType.CHAT_MESSAGE,
            sender_id=self.player_id,
            sequence=self.sequence_number,
            timestamp=time.time(),
            data=message.encode('utf-8')
        )
        
        self.sequence_number += 1
        
        # الإرسال للجميع
        self.send_to_all(packet)
    
    def _accept_connections(self):
        """استقبال اتصالات جديدة"""
        while self.running:
            try:
                client_socket, client_address = self.server_socket.accept()
                client_socket.settimeout(1.0)
                
                # استقبال حزمة المصافحة
                data = client_socket.recv(1024)
                if data:
                    handshake = self._parse_handshake(data)
                    if handshake:
                        self._handle_new_player(client_socket, client_address, handshake)
                
            except socket.timeout:
                continue
            except Exception as e:
                if self.running:
                    print(f"Accept error: {e}")
    
    def _handle_new_player(self, client_socket, client_address, handshake: dict):
        """معالجة لاعب جديد"""
        player_id = handshake.get('player_id', 0)
        player_name = handshake.get('name', 'Unknown')
        
        # التحقق من عدم وجود لاعب بنفس المعرف
        with self.players_lock:
            if player_id in self.players:
                print(f"Player ID {player_id} already exists")
                client_socket.close()
                return
            
            # التحقق من عدم تجاوز الحد الأقصى
            if len(self.players) >= self.max_players:
                print("Server is full")
                client_socket.close()
                return
            
            # إنشاء لاعب جديد
            new_player = NetworkPlayer(
                player_id=player_id,
                name=player_name,
                address=client_address,
                socket=client_socket,
                last_seen=time.time()
            )
            
            self.players[player_id] = new_player
            
            # بدء خيط استقبال البيانات لهذا اللاعب
            thread = threading.Thread(target=self._receive_from_player, 
                                    args=(player_id,), daemon=True)
            thread.start()
            
            print(f"👤 Player {player_name} ({player_id}) connected from {client_address[0]}:{client_address[1]}")
            
            # إرسال تأكيد الاتصال
            self._send_handshake_response(player_id, client_socket)
            
            # إعلام اللاعبين الآخرين
            self._notify_player_join(player_id, player_name)
            
            # استدعاء رد الفعل
            if self.on_player_join:
                self.on_player_join(player_id, player_name, client_address)
    
    def _receive_from_player(self, player_id: int):
        """استقبال بيانات من لاعب"""
        while self.running:
            try:
                with self.players_lock:
                    if player_id not in self.players:
                        break
                    
                    player = self.players[player_id]
                    if not player.socket:
                        break
                
                # استقبال البيانات
                data = player.socket.recv(MAX_PACKET_SIZE)
                if not data:
                    # اتصال مغلق
                    self._disconnect_player(player_id)
                    break
                
                # معالجة الحزمة
                packet = NetworkPacket.from_bytes(data)
                if packet:
                    self._process_packet(player_id, packet)
                    
                    # تحديث وقت آخر رؤية
                    with self.players_lock:
                        if player_id in self.players:
                            self.players[player_id].last_seen = time.time()
                
            except socket.timeout:
                continue
            except Exception as e:
                print(f"Receive error from player {player_id}: {e}")
                self._disconnect_player(player_id)
                break
    
    def _process_packet(self, sender_id: int, packet: NetworkPacket):
        """معالجة حزمة مستلمة"""
        if packet.packet_type == PacketType.POSITION_UPDATE:
            self._handle_position_update(sender_id, packet)
        elif packet.packet_type == PacketType.CHAT_MESSAGE:
            self._handle_chat_message(sender_id, packet)
        elif packet.packet_type == PacketType.PING:
            self._handle_ping(sender_id, packet)
    
    def _handle_position_update(self, sender_id: int, packet: NetworkPacket):
        """معالجة تحديث موقع"""
        if len(packet.data) >= 28:  # 6*4 + 2*2 = 28 بايت
            try:
                position = struct.unpack('<ffffffHH', packet.data[:28])
                
                with self.players_lock:
                    if sender_id in self.players:
                        player = self.players[sender_id]
                        player.position = (position[0], position[1], position[2])
                        player.rotation = (position[3], position[4], position[5])
                        player.health = position[6]
                        player.armor = position[7]
                        player.last_seen = time.time()
                
                # إعادة بث الموقع للاعبين الآخرين
                if sender_id != self.player_id:
                    self.send_to_all(packet, exclude_local=True)
                
                # استدعاء رد الفعل
                if self.on_position_update:
                    self.on_position_update(sender_id, 
                                          player.position, 
                                          player.rotation,
                                          player.health,
                                          player.armor)
                    
            except Exception as e:
                print(f"Position unpack error: {e}")
    
    def _handle_chat_message(self, sender_id: int, packet: NetworkPacket):
        """معالجة رسالة دردشة"""
        try:
            message = packet.data.decode('utf-8', errors='ignore')
            
            print(f"💬 {message}")
            
            # إعادة بث الرسالة
            self.send_to_all(packet)
            
            # استدعاء رد الفعل
            if self.on_chat_message:
                with self.players_lock:
                    sender_name = self.players[sender_id].name if sender_id in self.players else "Unknown"
                self.on_chat_message(sender_id, sender_name, message)
                
        except Exception as e:
            print(f"Chat decode error: {e}")
    
    def _handle_ping(self, sender_id: int, packet: NetworkPacket):
        """معالجة طلب ping"""
        # إرسال رد ping
        response = NetworkPacket(
            packet_type=PacketType.PING,
            sender_id=self.player_id,
            sequence=packet.sequence,
            timestamp=time.time(),
            data=b'pong'
        )
        
        self.send_to_player(sender_id, response)
    
    def _broadcast_presence(self):
        """بث وجود الخادم"""
        while self.running and self.broadcast_socket:
            try:
                # تحضير بيانات البث
                broadcast_data = {
                    'type': 'GTALAN_SERVER',
                    'id': self.player_id,
                    'name': self.player_name,
                    'port': NETWORK_PORT,
                    'players': len(self.players),
                    'max_players': self.max_players,
                    'timestamp': time.time()
                }
                
                message = json.dumps(broadcast_data).encode('utf-8')
                
                # البث على الشبكة المحلية
                self.broadcast_socket.sendto(
                    message, 
                    ('255.255.255.255', BROADCAST_PORT)
                )
                
                time.sleep(5)  # البث كل 5 ثواني
                
            except Exception as e:
                if self.running:
                    print(f"Broadcast error: {e}")
                    time.sleep(1)
    
    def _heartbeat_loop(self):
        """حلقة لمراقبة اتصال اللاعبين"""
        while self.running:
            time.sleep(HEARTBEAT_INTERVAL)
            
            current_time = time.time()
            disconnected_players = []
            
            with self.players_lock:
                for player_id, player in self.players.items():
                    if player.is_local:
                        continue
                    
                    # إذا انقطع الاتصال لأكثر من 10 ثواني
                    if current_time - player.last_seen > 10.0:
                        disconnected_players.append(player_id)
            
            # فصل اللاعبين المنقطعين
            for player_id in disconnected_players:
                self._disconnect_player(player_id)
    
    def _disconnect_player(self, player_id: int):
        """فصل لاعب"""
        with self.players_lock:
            if player_id in self.players:
                player = self.players[player_id]
                
                # إغلاق المقبس
                if player.socket:
                    try:
                        player.socket.close()
                    except:
                        pass
                
                # إزالة اللاعب
                del self.players[player_id]
                
                # إعلام اللاعبين الآخرين
                if player_id != self.player_id:
                    self._notify_player_leave(player_id)
                
                print(f"👤 Player {player.name} ({player_id}) disconnected")
                
                # استدعاء رد الفعل
                if self.on_player_leave:
                    self.on_player_leave(player_id, player.name)
    
    def _parse_handshake(self, data: bytes) -> Optional[dict]:
        """تحليل حزمة المصافحة"""
        try:
            handshake = json.loads(data.decode('utf-8'))
            if handshake.get('type') == 'handshake':
                return handshake
        except:
            pass
        return None
    
    def _send_handshake_response(self, player_id: int, client_socket: socket.socket):
        """إرسال رد المصافحة"""
        response = {
            'type': 'handshake_response',
            'status': 'accepted',
            'assigned_id': player_id,
            'server_name': self.player_name,
            'player_count': len(self.players)
        }
        
        try:
            client_socket.send(json.dumps(response).encode('utf-8'))
        except:
            pass
    
    def _notify_player_join(self, player_id: int, player_name: str):
        """إعلام اللاعبين بانضمام لاعب جديد"""
        notification = {
            'type': 'player_join',
            'player_id': player_id,
            'player_name': player_name,
            'timestamp': time.time()
        }
        
        packet = NetworkPacket(
            packet_type=PacketType.PLAYER_JOIN,
            sender_id=self.player_id,
            sequence=self.sequence_number,
            timestamp=time.time(),
            data=json.dumps(notification).encode('utf-8')
        )
        
        self.sequence_number += 1
        self.send_to_all(packet, exclude_local=True)
    
    def _notify_player_leave(self, player_id: int):
        """إعلام اللاعبين بمغادرة لاعب"""
        notification = {
            'type': 'player_leave',
            'player_id': player_id,
            'timestamp': time.time()
        }
        
        packet = NetworkPacket(
            packet_type=PacketType.PLAYER_LEAVE,
            sender_id=self.player_id,
            sequence=self.sequence_number,
            timestamp=time.time(),
            data=json.dumps(notification).encode('utf-8')
        )
        
        self.sequence_number += 1
        self.send_to_all(packet, exclude_local=True)
    
    def get_player_list(self) -> List[dict]:
        """الحصول على قائمة اللاعبين"""
        with self.players_lock:
            return [
                {
                    'id': player.player_id,
                    'name': player.name,
                    'address': player.address,
                    'is_local': player.is_local,
                    'position': player.position,
                    'health': player.health,
                    'last_seen': player.last_seen
                }
                for player in self.players.values()
            ]
    
    def get_player_count(self) -> int:
        """الحصول على عدد اللاعبين"""
        with self.players_lock:
            return len(self.players)

class LANClient:
    """عميل LAN"""
    
    def __init__(self, player_id: int, player_name: str):
        self.player_id = player_id
        self.player_name = player_name
        
        self.connected = False
        self.server_socket = None
        self.server_address = None
        
        self.players: Dict[int, NetworkPlayer] = {}
        self.players_lock = threading.RLock()
        
        self.receive_thread = None
        self.heartbeat_thread = None
        
        # استدعاءات رد الفعل
        self.on_connected: Optional[Callable] = None
        self.on_disconnected: Optional[Callable] = None
        self.on_player_join: Optional[Callable] = None
        self.on_player_leave: Optional[Callable] = None
        self.on_position_update: Optional[Callable] = None
        self.on_chat_message: Optional[Callable] = None
    
    def connect(self, server_ip: str, port: int = NETWORK_PORT) -> bool:
        """الاتصال بخادم"""
        try:
            # إنشاء المقبس
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.settimeout(CONNECT_TIMEOUT)
            
            # الاتصال
            self.server_socket.connect((server_ip, port))
            self.server_socket.settimeout(1.0)
            
            self.server_address = (server_ip, port)
            
            # إرسال حزمة المصافحة
            handshake = {
                'type': 'handshake',
                'player_id': self.player_id,
                'name': self.player_name,
                'version': '1.0',
                'timestamp': time.time()
            }
            
            self.server_socket.send(json.dumps(handshake).encode('utf-8'))
            
            # استقبال الرد
            response_data = self.server_socket.recv(1024)
            if not response_data:
                self.disconnect()
                return False
            
            response = json.loads(response_data.decode('utf-8'))
            if response.get('status') != 'accepted':
                self.disconnect()
                return False
            
            self.connected = True
            
            # بدء خيط استقبال البيانات
            self.receive_thread = threading.Thread(target=self._receive_loop, daemon=True)
            self.receive_thread.start()
            
            # بدء خيط المراقبة
            self.heartbeat_thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
            self.heartbeat_thread.start()
            
            print(f"✅ Connected to server {server_ip}:{port}")
            
            # إضافة اللاعب المحلي
            with self.players_lock:
                self.players[self.player_id] = NetworkPlayer(
                    player_id=self.player_id,
                    name=self.player_name,
                    address=('127.0.0.1', 0),
                    socket=None,
                    last_seen=time.time(),
                    is_local=True
                )
            
            # استدعاء رد الفعل
            if self.on_connected:
                self.on_connected(server_ip, port)
            
            return True
            
        except Exception as e:
            print(f"❌ Connection failed: {e}")
            self.disconnect()
            return False
    
    def disconnect(self):
        """قطع الاتصال"""
        self.connected = False
        
        if self.server_socket:
            try:
                self.server_socket.close()
            except:
                pass
        
        with self.players_lock:
            self.players.clear()
        
        print("✅ Disconnected from server")
        
        # استدعاء رد الفعل
        if self.on_disconnected:
            self.on_disconnected()
    
    def send_position(self, position: Tuple[float, float, float], 
                     rotation: Tuple[float, float, float],
                     health: int = 100, armor: int = 0):
        """إرسال موقع اللاعب"""
        if not self.connected or not self.server_socket:
            return
        
        try:
            # تحضير البيانات
            position_data = struct.pack('<ffffffHH',
                                      position[0], position[1], position[2],
                                      rotation[0], rotation[1], rotation[2],
                                      health, armor)
            
            # إنشاء الحزمة
            packet = NetworkPacket(
                packet_type=PacketType.POSITION_UPDATE,
                sender_id=self.player_id,
                sequence=0,  # سيتولى الخادم ترقيم التسلسل
                timestamp=time.time(),
                data=position_data
            )
            
            # الإرسال
            self.server_socket.sendall(packet.to_bytes())
            
        except Exception as e:
            print(f"Send position error: {e}")
            self.disconnect()
    
    def send_chat(self, message: str):
        """إرسال رسالة دردشة"""
        if not self.connected or not self.server_socket:
            return
        
        try:
            # إنشاء الحزمة
            packet = NetworkPacket(
                packet_type=PacketType.CHAT_MESSAGE,
                sender_id=self.player_id,
                sequence=0,
                timestamp=time.time(),
                data=message.encode('utf-8')
            )
            
            # الإرسال
            self.server_socket.sendall(packet.to_bytes())
            
        except Exception as e:
            print(f"Send chat error: {e}")
    
    def discover_servers(self, timeout: float = 3.0) -> List[dict]:
        """اكتشاف خوادم LAN"""
        servers = []
        
        try:
            # إنشاء مقبس للبث
            discover_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            discover_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            discover_socket.settimeout(timeout)
            
            # الربط
            discover_socket.bind(('0.0.0.0', BROADCAST_PORT))
            
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    data, address = discover_socket.recvfrom(1024)
                    
                    try:
                        server_info = json.loads(data.decode('utf-8'))
                        
                        if server_info.get('type') == 'GTALAN_SERVER':
                            servers.append({
                                'ip': address[0],
                                'port': server_info.get('port', NETWORK_PORT),
                                'name': server_info.get('name', 'Unknown'),
                                'players': server_info.get('players', 0),
                                'max_players': server_info.get('max_players', 16),
                                'id': server_info.get('id', 0)
                            })
                    except:
                        continue
                        
                except socket.timeout:
                    break
                except Exception as e:
                    print(f"Discover error: {e}")
                    break
            
            discover_socket.close()
            
        except Exception as e:
            print(f"Discover setup error: {e}")
        
        return servers
    
    def _receive_loop(self):
        """حلقة استقبال البيانات"""
        while self.connected and self.server_socket:
            try:
                data = self.server_socket.recv(MAX_PACKET_SIZE)
                if not data:
                    self.disconnect()
                    break
                
                # معالجة الحزمة
                packet = NetworkPacket.from_bytes(data)
                if packet:
                    self._process_packet(packet)
                    
            except socket.timeout:
                continue
            except Exception as e:
                print(f"Receive error: {e}")
                self.disconnect()
                break
    
    def _process_packet(self, packet: NetworkPacket):
        """معالجة حزمة مستلمة"""
        if packet.packet_type == PacketType.POSITION_UPDATE:
            self._handle_position_update(packet)
        elif packet.packet_type == PacketType.CHAT_MESSAGE:
            self._handle_chat_message(packet)
        elif packet.packet_type == PacketType.PLAYER_JOIN:
            self._handle_player_join(packet)
        elif packet.packet_type == PacketType.PLAYER_LEAVE:
            self._handle_player_leave(packet)
        elif packet.packet_type == PacketType.PING:
            self._handle_ping(packet)
    
    def _handle_position_update(self, packet: NetworkPacket):
        """معالجة تحديث موقع"""
        if len(packet.data) >= 28:
            try:
                position = struct.unpack('<ffffffHH', packet.data[:28])
                
                with self.players_lock:
                    if packet.sender_id in self.players:
                        player = self.players[packet.sender_id]
                        player.position = (position[0], position[1], position[2])
                        player.rotation = (position[3], position[4], position[5])
                        player.health = position[6]
                        player.armor = position[7]
                        player.last_seen = time.time()
                    else:
                        # لاعب جديد
                        self.players[packet.sender_id] = NetworkPlayer(
                            player_id=packet.sender_id,
                            name=f'Player_{packet.sender_id}',
                            address=None,
                            socket=None,
                            last_seen=time.time(),
                            position=(position[0], position[1], position[2]),
                            rotation=(position[3], position[4], position[5]),
                            health=position[6],
                            armor=position[7]
                        )
                
                # استدعاء رد الفعل
                if self.on_position_update:
                    self.on_position_update(packet.sender_id, 
                                          (position[0], position[1], position[2]),
                                          (position[3], position[4], position[5]),
                                          position[6],
                                          position[7])
                    
            except Exception as e:
                print(f"Position unpack error: {e}")
    
    def _handle_chat_message(self, packet: NetworkPacket):
        """معالجة رسالة دردشة"""
        try:
            message = packet.data.decode('utf-8', errors='ignore')
            
            # استدعاء رد الفعل
            if self.on_chat_message:
                with self.players_lock:
                    sender_name = self.players[packet.sender_id].name if packet.sender_id in self.players else "Unknown"
                self.on_chat_message(packet.sender_id, sender_name, message)
                
        except Exception as e:
            print(f"Chat decode error: {e}")
    
    def _handle_player_join(self, packet: NetworkPacket):
        """معالجة انضمام لاعب"""
        try:
            data = json.loads(packet.data.decode('utf-8'))
            player_id = data.get('player_id')
            player_name = data.get('player_name')
            
            with self.players_lock:
                if player_id not in self.players:
                    self.players[player_id] = NetworkPlayer(
                        player_id=player_id,
                        name=player_name,
                        address=None,
                        socket=None,
                        last_seen=time.time()
                    )
            
            print(f"👤 Player {player_name} ({player_id}) joined")
            
            # استدعاء رد الفعل
            if self.on_player_join:
                self.on_player_join(player_id, player_name)
                
        except Exception as e:
            print(f"Player join parse error: {e}")
    
    def _handle_player_leave(self, packet: NetworkPacket):
        """معالجة مغادرة لاعب"""
        try:
            data = json.loads(packet.data.decode('utf-8'))
            player_id = data.get('player_id')
            
            with self.players_lock:
                if player_id in self.players:
                    player_name = self.players[player_id].name
                    del self.players[player_id]
                    
                    print(f"👤 Player {player_name} ({player_id}) left")
                    
                    # استدعاء رد الفعل
                    if self.on_player_leave:
                        self.on_player_leave(player_id, player_name)
                        
        except Exception as e:
            print(f"Player leave parse error: {e}")
    
    def _handle_ping(self, packet: NetworkPacket):
        """معالجة طلب ping"""
        # لا حاجة للرد، الخادم يرسل ping فقط
        pass
    
    def _heartbeat_loop(self):
        """حلقة مراقبة الاتصال"""
        while self.connected:
            time.sleep(HEARTBEAT_INTERVAL)
            
            # إرسال ping للخادم
            if self.connected and self.server_socket:
                try:
                    ping_packet = NetworkPacket(
                        packet_type=PacketType.PING,
                        sender_id=self.player_id,
                        sequence=0,
                        timestamp=time.time(),
                        data=b'ping'
                    )
                    
                    self.server_socket.sendall(ping_packet.to_bytes())
                    
                except Exception as e:
                    print(f"Heartbeat error: {e}")
                    self.disconnect()
                    break
    
    def get_player_list(self) -> List[dict]:
        """الحصول على قائمة اللاعبين"""
        with self.players_lock:
            return [
                {
                    'id': player.player_id,
                    'name': player.name,
                    'is_local': player.is_local,
                    'position': player.position,
                    'health': player.health,
                    'last_seen': player.last_seen
                }
                for player in self.players.values()
            ]
    
    def get_player_count(self) -> int:
        """الحصول على عدد اللاعبين"""
        with self.players_lock:
            return len(self.players)
    
    def is_connected(self) -> bool:
        """التحقق من الاتصال"""
        return self.connected

class NetworkManager:
    """مدير الشبكة الرئيسي"""
    
    def __init__(self):
        self.mode = None  # 'host' أو 'client'
        self.server = None
        self.client = None
        self.local_player_id = id(self)
        self.local_player_name = "Player_" + str(self.local_player_id)[-4:]
        
        # الإعدادات
        self.network_port = NETWORK_PORT
        self.broadcast_port = BROADCAST_PORT
        
        # الحالة
        self.connected = False
        self.discovered_servers = []
        
        # استدعاءات رد الفعل
        self.callbacks = {}
    
    def start_host(self, player_name: str = None, max_players: int = 16) -> bool:
        """بدء خادم مضيف"""
        if self.mode is not None:
            return False
        
        if player_name:
            self.local_player_name = player_name
        
        try:
            self.server = LANServer(self.local_player_id, self.local_player_name, max_players)
            
            # تعيين ردود الفعل
            self.server.on_player_join = self._on_player_join
            self.server.on_player_leave = self._on_player_leave
            self.server.on_position_update = self._on_position_update
            self.server.on_chat_message = self._on_chat_message
            
            if self.server.start(self.network_port):
                self.mode = 'host'
                self.connected = True
                return True
            
        except Exception as e:
            print(f"Failed to start host: {e}")
        
        return False
    
    def connect_to_server(self, server_ip: str, port: int = NETWORK_PORT, 
                         player_name: str = None) -> bool:
        """الاتصال بخادم"""
        if self.mode is not None:
            return False
        
        if player_name:
            self.local_player_name = player_name
        
        try:
            self.client = LANClient(self.local_player_id, self.local_player_name)
            
            # تعيين ردود الفعل
            self.client.on_connected = self._on_connected
            self.client.on_disconnected = self._on_disconnected
            self.client.on_player_join = self._on_player_join
            self.client.on_player_leave = self._on_player_leave
            self.client.on_position_update = self._on_position_update
            self.client.on_chat_message = self._on_chat_message
            
            if self.client.connect(server_ip, port):
                self.mode = 'client'
                self.connected = True
                return True
            
        except Exception as e:
            print(f"Failed to connect to server: {e}")
        
        return False
    
    def disconnect(self):
        """قطع الاتصال"""
        if self.mode == 'host' and self.server:
            self.server.stop()
            self.server = None
        elif self.mode == 'client' and self.client:
            self.client.disconnect()
            self.client = None
        
        self.mode = None
        self.connected = False
    
    def send_position(self, position: Tuple[float, float, float], 
                     rotation: Tuple[float, float, float],
                     health: int = 100, armor: int = 0):
        """إرسال موقع اللاعب"""
        if self.mode == 'host' and self.server:
            self.server.broadcast_position(position, rotation, health, armor)
        elif self.mode == 'client' and self.client and self.client.is_connected():
            self.client.send_position(position, rotation, health, armor)
    
    def send_chat(self, message: str):
        """إرسال رسالة دردشة"""
        if self.mode == 'host' and self.server:
            self.server.broadcast_chat(message)
        elif self.mode == 'client' and self.client and self.client.is_connected():
            self.client.send_chat(message)
    
    def discover_servers(self, timeout: float = 3.0) -> List[dict]:
        """اكتشاف خوادم LAN"""
        if self.client:
            self.discovered_servers = self.client.discover_servers(timeout)
        else:
            temp_client = LANClient(self.local_player_id, self.local_player_name)
            self.discovered_servers = temp_client.discover_servers(timeout)
        
        return self.discovered_servers
    
    def get_player_list(self) -> List[dict]:
        """الحصول على قائمة اللاعبين"""
        if self.mode == 'host' and self.server:
            return self.server.get_player_list()
        elif self.mode == 'client' and self.client:
            return self.client.get_player_list()
        return []
    
    def get_player_count(self) -> int:
        """الحصول على عدد اللاعبين"""
        if self.mode == 'host' and self.server:
            return self.server.get_player_count()
        elif self.mode == 'client' and self.client:
            return self.client.get_player_count()
        return 0
    
    def is_host(self) -> bool:
        """التحقق إذا كان مضيفًا"""
        return self.mode == 'host'
    
    def is_client(self) -> bool:
        """التحقق إذا كان عميلًا"""
        return self.mode == 'client'
    
    def is_connected(self) -> bool:
        """التحقق من الاتصال"""
        return self.connected
    
    def register_callback(self, event: str, callback: Callable):
        """تسجيل رد فعل لحدث"""
        self.callbacks[event] = callback
    
    def _trigger_callback(self, event: str, *args, **kwargs):
        """تشغيل رد فعل"""
        if event in self.callbacks:
            try:
                self.callbacks[event](*args, **kwargs)
            except Exception as e:
                print(f"Callback error for {event}: {e}")
    
    def _on_connected(self, server_ip: str, port: int):
        """عند الاتصال بالخادم"""
        self._trigger_callback('connected', server_ip, port)
    
    def _on_disconnected(self):
        """عند قطع الاتصال"""
        self._trigger_callback('disconnected')
    
    def _on_player_join(self, player_id: int, player_name: str, address=None):
        """عند انضمام لاعب"""
        self._trigger_callback('player_join', player_id, player_name, address)
    
    def _on_player_leave(self, player_id: int, player_name: str):
        """عند مغادرة لاعب"""
        self._trigger_callback('player_leave', player_id, player_name)
    
    def _on_position_update(self, player_id: int, position: Tuple, rotation: Tuple, 
                           health: int, armor: int):
        """عند تحديث موقع لاعب"""
        self._trigger_callback('position_update', player_id, position, rotation, health, armor)
    
    def _on_chat_message(self, player_id: int, player_name: str, message: str):
        """عند استقبال رسالة دردشة"""
        self._trigger_callback('chat_message', player_id, player_name, message)

# ==================== اختبار النظام ====================
if __name__ == "__main__":
    # اختبار النظام
    network = NetworkManager()
    
    def on_position_update(player_id, position, rotation, health, armor):
        print(f"Player {player_id} moved to {position}")
    
    def on_chat_message(player_id, player_name, message):
        print(f"[{player_name}]: {message}")
    
    # تسجيل ردود الفعل
    network.register_callback('position_update', on_position_update)
    network.register_callback('chat_message', on_chat_message)
    
    print("Network System Test")
    print("1. Start as Host")
    print("2. Connect as Client")
    print("3. Discover Servers")
    
    choice = input("Choice: ")
    
    if choice == "1":
        # اختبار المضيف
        if network.start_host("TestHost", 4):
            print("Host started successfully!")
            
            # محاكاة إرسال موقع
            import time
            for i in range(10):
                network.send_position((i*10, 100, 10), (0, 0, i*10))
                network.send_chat(f"Test message {i}")
                time.sleep(1)
            
            network.disconnect()
    
    elif choice == "2":
        # اختبار العميل
        server_ip = input("Server IP: ")
        if network.connect_to_server(server_ip, NETWORK_PORT, "TestClient"):
            print("Connected to server!")
            
            # محاكاة إرسال موقع
            import time
            for i in range(10):
                network.send_position((i*5, 50, 5), (0, 0, i*5))
                time.sleep(1)
            
            network.disconnect()
    
    elif choice == "3":
        # اكتشاف الخوادم
        print("Discovering servers...")
        servers = network.discover_servers(5.0)
        
        if servers:
            print(f"Found {len(servers)} servers:")
            for i, server in enumerate(servers, 1):
                print(f"{i}. {server['name']} ({server['ip']}:{server['port']})")
                print(f"   Players: {server['players']}/{server['max_players']}")
        else:
            print("No servers found")