// MultiplayerCore_Network.cpp - نظام شبكة متكامل
#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdio.h>
#include <vector>
#include <thread>
#include <atomic>
#include <mutex>
#include <map>
#include <queue>
#include <chrono>

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "wsock32.lib")

// ==================== تعريفات الشبكة ====================
#define NETWORK_PORT 5192
#define BROADCAST_PORT 9999
#define MAX_PACKET_SIZE 1024
#define MAX_PLAYERS 32
#define NETWORK_TIMEOUT 5000  // 5 ثواني

// أنواع الحزم
enum PacketType {
    PACKET_HANDSHAKE = 0x01,      // مصافحة
    PACKET_POSITION_UPDATE = 0x02, // تحديث موقع
    PACKET_PLAYER_JOIN = 0x03,    // لاعب انضم
    PACKET_PLAYER_LEAVE = 0x04,   // لاعب غادر
    PACKET_CHAT_MESSAGE = 0x05,   // رسالة دردشة
    PACKET_VEHICLE_UPDATE = 0x06, // تحديث مركبة
    PACKET_PING = 0x07,           // اختبار اتصال
    PACKET_GAME_STATE = 0x08      // حالة اللعبة
};

// هيكل الحزمة الأساسي
#pragma pack(push, 1)
struct NetworkPacket {
    BYTE packetType;
    DWORD senderID;
    DWORD sequenceNumber;
    DWORD timestamp;
    BYTE data[MAX_PACKET_SIZE - 12];
    
    // الحصول على حجم البيانات الفعلي
    DWORD GetDataSize() const { 
        return MAX_PACKET_SIZE - 12; 
    }
};

// حزمة تحديث الموقع
struct PositionPacket {
    float positionX;
    float positionY;
    float positionZ;
    float rotationX;
    float rotationY;
    float rotationZ;
    float velocityX;
    float velocityY;
    float velocityZ;
    WORD animation;
    BYTE health;
    BYTE armor;
    BYTE weaponID;
    BYTE vehicleID;
};

// حزمة مصافحة
struct HandshakePacket {
    DWORD playerID;
    char playerName[32];
    BYTE gameVersion;
    DWORD capabilities;
};
#pragma pack(pop)

// ==================== فئة اتصال لاعب ====================
class PlayerConnection {
private:
    SOCKET socket;
    sockaddr_in address;
    DWORD playerID;
    std::string playerName;
    std::atomic<bool> connected;
    std::atomic<DWORD> lastPingTime;
    std::thread receiveThread;
    std::atomic<bool> threadRunning;
    
    // طابور الإرسال
    std::queue<NetworkPacket> sendQueue;
    std::mutex queueMutex;
    std::condition_variable queueCV;
    
public:
    PlayerConnection(SOCKET sock, sockaddr_in addr, DWORD id, const char* name) 
        : socket(sock), address(addr), playerID(id), playerName(name), 
          connected(true), threadRunning(true) {
        
        lastPingTime = GetTickCount();
        
        // بدء خيط الاستقبال
        receiveThread = std::thread(&PlayerConnection::ReceiveThread, this);
        
        // بدء خيط الإرسال
        std::thread(&PlayerConnection::SendThread, this).detach();
    }
    
    ~PlayerConnection() {
        Disconnect();
    }
    
    void Disconnect() {
        connected = false;
        threadRunning = false;
        
        if (socket != INVALID_SOCKET) {
            shutdown(socket, SD_BOTH);
            closesocket(socket);
            socket = INVALID_SOCKET;
        }
        
        if (receiveThread.joinable()) {
            receiveThread.join();
        }
        
        // تفريغ الطابور
        std::lock_guard<std::mutex> lock(queueMutex);
        while (!sendQueue.empty()) {
            sendQueue.pop();
        }
        queueCV.notify_all();
    }
    
    bool IsConnected() const { 
        return connected && (GetTickCount() - lastPingTime < NETWORK_TIMEOUT); 
    }
    
    void UpdatePingTime() { 
        lastPingTime = GetTickCount(); 
    }
    
    DWORD GetPlayerID() const { 
        return playerID; 
    }
    
    std::string GetPlayerName() const { 
        return playerName; 
    }
    
    sockaddr_in GetAddress() const { 
        return address; 
    }
    
    // إضافة حزمة للإرسال
    void SendPacket(const NetworkPacket& packet) {
        std::lock_guard<std::mutex> lock(queueMutex);
        sendQueue.push(packet);
        queueCV.notify_one();
    }
    
    void SendPositionUpdate(const PositionPacket& position) {
        NetworkPacket packet;
        packet.packetType = PACKET_POSITION_UPDATE;
        packet.senderID = playerID;
        packet.timestamp = GetTickCount();
        
        memcpy(packet.data, &position, sizeof(PositionPacket));
        SendPacket(packet);
    }
    
    void SendChatMessage(const char* message) {
        NetworkPacket packet;
        packet.packetType = PACKET_CHAT_MESSAGE;
        packet.senderID = playerID;
        packet.timestamp = GetTickCount();
        
        strncpy_s((char*)packet.data, packet.GetDataSize(), message, packet.GetDataSize() - 1);
        SendPacket(packet);
    }
    
private:
    void ReceiveThread() {
        char buffer[MAX_PACKET_SIZE];
        
        while (threadRunning && socket != INVALID_SOCKET) {
            fd_set readSet;
            FD_ZERO(&readSet);
            FD_SET(socket, &readSet);
            
            timeval timeout = { 1, 0 }; // انتظار 1 ثانية
            
            int result = select(0, &readSet, NULL, NULL, &timeout);
            
            if (result > 0 && FD_ISSET(socket, &readSet)) {
                int bytesReceived = recv(socket, buffer, MAX_PACKET_SIZE, 0);
                
                if (bytesReceived > 0) {
                    ProcessReceivedData(buffer, bytesReceived);
                    UpdatePingTime();
                }
                else if (bytesReceived == 0) {
                    // اتصال مغلق
                    connected = false;
                    break;
                }
                else {
                    // خطأ في الاستقبال
                    int error = WSAGetLastError();
                    if (error != WSAEWOULDBLOCK) {
                        connected = false;
                        break;
                    }
                }
            }
            else if (result == 0) {
                // timeout - مواصلة الانتظار
                continue;
            }
            else {
                // خطأ في select
                connected = false;
                break;
            }
        }
    }
    
    void SendThread() {
        while (threadRunning) {
            NetworkPacket packet;
            
            {
                std::unique_lock<std::mutex> lock(queueMutex);
                queueCV.wait(lock, [this] { 
                    return !sendQueue.empty() || !threadRunning; 
                });
                
                if (!threadRunning) break;
                
                if (!sendQueue.empty()) {
                    packet = sendQueue.front();
                    sendQueue.pop();
                }
                else {
                    continue;
                }
            }
            
            // الإرسال الفعلي
            if (socket != INVALID_SOCKET) {
                send(socket, (char*)&packet, sizeof(NetworkPacket), 0);
            }
        }
    }
    
    void ProcessReceivedData(const char* data, int size) {
        if (size < (int)sizeof(NetworkPacket)) return;
        
        NetworkPacket* packet = (NetworkPacket*)data;
        
        switch (packet->packetType) {
            case PACKET_POSITION_UPDATE:
                OnPositionUpdate(packet);
                break;
            case PACKET_CHAT_MESSAGE:
                OnChatMessage(packet);
                break;
            case PACKET_PING:
                SendPingResponse();
                break;
            default:
                break;
        }
    }
    
    void OnPositionUpdate(NetworkPacket* packet) {
        if (packet->senderID == playerID) return; // تجاهل حزم نفس اللاعب
        
        PositionPacket* position = (PositionPacket*)packet->data;
        
        // تحديث موقع اللاعب في الذاكرة
        // سيتم استدعاء هذه الدالة من مدير الذاكرة
        printf("Position update from player %d: (%.2f, %.2f, %.2f)\n", 
               packet->senderID, 
               position->positionX, 
               position->positionY, 
               position->positionZ);
    }
    
    void OnChatMessage(NetworkPacket* packet) {
        char message[256];
        strncpy_s(message, (char*)packet->data, 255);
        
        printf("Chat from player %d: %s\n", packet->senderID, message);
    }
    
    void SendPingResponse() {
        NetworkPacket packet;
        packet.packetType = PACKET_PING;
        packet.senderID = playerID;
        packet.timestamp = GetTickCount();
        
        SendPacket(packet);
    }
};

// ==================== فئة خادم الشبكة ====================
class NetworkServer {
private:
    SOCKET serverSocket;
    SOCKET broadcastSocket;
    std::atomic<bool> running;
    std::thread acceptThread;
    std::thread broadcastThread;
    std::map<DWORD, PlayerConnection*> players;
    std::mutex playersMutex;
    
    DWORD localPlayerID;
    char serverName[64];
    BYTE maxPlayers;
    
public:
    NetworkServer(DWORD playerID, const char* name, BYTE maxPlayers = 16) 
        : serverSocket(INVALID_SOCKET), broadcastSocket(INVALID_SOCKET),
          running(false), localPlayerID(playerID), maxPlayers(maxPlayers) {
        
        strncpy_s(serverName, name, 63);
    }
    
    ~NetworkServer() {
        Stop();
    }
    
    bool Start() {
        if (running) return true;
        
        // تهيئة Winsock
        WSADATA wsaData;
        if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
            printf("WSAStartup failed\n");
            return false;
        }
        
        // إنشاء مقبس الخادم
        serverSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (serverSocket == INVALID_SOCKET) {
            printf("Failed to create server socket\n");
            return false;
        }
        
        // تعيين خيارات المقبس
        BOOL reuseAddr = TRUE;
        setsockopt(serverSocket, SOL_SOCKET, SO_REUSEADDR, 
                  (char*)&reuseAddr, sizeof(reuseAddr));
        
        // ربط المقبس
        sockaddr_in serverAddr;
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_port = htons(NETWORK_PORT);
        serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);
        
        if (bind(serverSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
            printf("Failed to bind server socket\n");
            closesocket(serverSocket);
            return false;
        }
        
        // الاستماع للاتصالات الواردة
        if (listen(serverSocket, SOMAXCONN) == SOCKET_ERROR) {
            printf("Failed to listen on server socket\n");
            closesocket(serverSocket);
            return false;
        }
        
        // إنشاء مقبس البث
        broadcastSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (broadcastSocket != INVALID_SOCKET) {
            BOOL broadcast = TRUE;
            setsockopt(broadcastSocket, SOL_SOCKET, SO_BROADCAST, 
                      (char*)&broadcast, sizeof(broadcast));
        }
        
        running = true;
        
        // بدء خيوط العمل
        acceptThread = std::thread(&NetworkServer::AcceptThread, this);
        broadcastThread = std::thread(&NetworkServer::BroadcastThread, this);
        
        printf("Network server started on port %d\n", NETWORK_PORT);
        return true;
    }
    
    void Stop() {
        running = false;
        
        // إغلاق المقابس
        if (serverSocket != INVALID_SOCKET) {
            closesocket(serverSocket);
            serverSocket = INVALID_SOCKET;
        }
        
        if (broadcastSocket != INVALID_SOCKET) {
            closesocket(broadcastSocket);
            broadcastSocket = INVALID_SOCKET;
        }
        
        // فصل جميع اللاعبين
        {
            std::lock_guard<std::mutex> lock(playersMutex);
            for (auto& pair : players) {
                delete pair.second;
            }
            players.clear();
        }
        
        // انتظار إنهاء الخيوط
        if (acceptThread.joinable()) {
            acceptThread.join();
        }
        
        if (broadcastThread.joinable()) {
            broadcastThread.join();
        }
        
        WSACleanup();
        printf("Network server stopped\n");
    }
    
    void BroadcastPosition(const PositionPacket& position) {
        std::lock_guard<std::mutex> lock(playersMutex);
        
        for (auto& pair : players) {
            if (pair.second->IsConnected()) {
                pair.second->SendPositionUpdate(position);
            }
        }
    }
    
    void BroadcastChatMessage(const char* message) {
        std::lock_guard<std::mutex> lock(playersMutex);
        
        for (auto& pair : players) {
            if (pair.second->IsConnected()) {
                pair.second->SendChatMessage(message);
            }
        }
    }
    
    int GetPlayerCount() const {
        std::lock_guard<std::mutex> lock(playersMutex);
        return (int)players.size();
    }
    
private:
    void AcceptThread() {
        while (running) {
            fd_set readSet;
            FD_ZERO(&readSet);
            FD_SET(serverSocket, &readSet);
            
            timeval timeout = { 1, 0 };
            
            int result = select(0, &readSet, NULL, NULL, &timeout);
            
            if (result > 0 && FD_ISSET(serverSocket, &readSet)) {
                sockaddr_in clientAddr;
                int addrLen = sizeof(clientAddr);
                
                SOCKET clientSocket = accept(serverSocket, (sockaddr*)&clientAddr, &addrLen);
                
                if (clientSocket != INVALID_SOCKET) {
                    // قبول اللاعب الجديد
                    HandleNewConnection(clientSocket, clientAddr);
                }
            }
        }
    }
    
    void HandleNewConnection(SOCKET clientSocket, sockaddr_in clientAddr) {
        // استقبال حزمة المصافحة
        HandshakePacket handshake;
        int bytesReceived = recv(clientSocket, (char*)&handshake, sizeof(HandshakePacket), 0);
        
        if (bytesReceived == sizeof(HandshakePacket)) {
            // التحقق من الإصدار والقدرات
            if (handshake.gameVersion == 1) { // إصدار متوافق
                std::lock_guard<std::mutex> lock(playersMutex);
                
                // التحقق من عدم تجاوز الحد الأقصى
                if (players.size() >= maxPlayers) {
                    printf("Server full, rejecting player %d\n", handshake.playerID);
                    closesocket(clientSocket);
                    return;
                }
                
                // التحقق من عدم وجود لاعب بنفس المعرف
                if (players.find(handshake.playerID) != players.end()) {
                    printf("Player ID %d already exists\n", handshake.playerID);
                    closesocket(clientSocket);
                    return;
                }
                
                // إنشاء اتصال جديد
                PlayerConnection* connection = new PlayerConnection(
                    clientSocket, clientAddr, handshake.playerID, handshake.playerName);
                
                players[handshake.playerID] = connection;
                
                printf("Player %s (%d) connected from %s:%d\n", 
                       handshake.playerName, handshake.playerID,
                       inet_ntoa(clientAddr.sin_addr), ntohs(clientAddr.sin_port));
                
                // إرسال تأكيد الاتصال
                SendConnectionAccept(clientSocket, handshake.playerID);
                
                // إعلام اللاعبين الآخرين
                BroadcastPlayerJoin(handshake.playerID, handshake.playerName);
            }
            else {
                printf("Incompatible game version from player\n");
                closesocket(clientSocket);
            }
        }
        else {
            closesocket(clientSocket);
        }
    }
    
    void SendConnectionAccept(SOCKET socket, DWORD playerID) {
        NetworkPacket packet;
        packet.packetType = PACKET_HANDSHAKE;
        packet.senderID = localPlayerID;
        packet.timestamp = GetTickCount();
        
        // إضافة بيانات إضافية
        DWORD* data = (DWORD*)packet.data;
        data[0] = playerID; // تأكيد المعرف
        data[1] = GetPlayerCount(); // عدد اللاعبين الحالي
        
        send(socket, (char*)&packet, sizeof(NetworkPacket), 0);
    }
    
    void BroadcastPlayerJoin(DWORD playerID, const char* playerName) {
        std::lock_guard<std::mutex> lock(playersMutex);
        
        NetworkPacket packet;
        packet.packetType = PACKET_PLAYER_JOIN;
        packet.senderID = playerID;
        packet.timestamp = GetTickCount();
        
        // إضافة اسم اللاعب
        strncpy_s((char*)packet.data, packet.GetDataSize(), playerName, packet.GetDataSize() - 1);
        
        for (auto& pair : players) {
            if (pair.first != playerID && pair.second->IsConnected()) {
                pair.second->SendPacket(packet);
            }
        }
    }
    
    void BroadcastThread() {
        while (running && broadcastSocket != INVALID_SOCKET) {
            // إعداد حزمة البث
            struct BroadcastPacket {
                DWORD magic;        // 0x474E414C = "LAN"
                DWORD serverID;     // معرف السيرفر
                BYTE gameType;      // نوع اللعبة
                BYTE playerCount;   // عدد اللاعبين
                BYTE maxPlayers;    // الحد الأقصى
                WORD port;          // المنفذ
                char serverName[32]; // اسم السيرفر
            } broadcast;
            
            broadcast.magic = 0x474E414C; // "LAN"
            broadcast.serverID = localPlayerID;
            broadcast.gameType = 0; // deathmatch
            broadcast.playerCount = (BYTE)GetPlayerCount();
            broadcast.maxPlayers = maxPlayers;
            broadcast.port = NETWORK_PORT;
            strncpy_s(broadcast.serverName, serverName, 31);
            
            // إرسال البث
            sockaddr_in broadcastAddr;
            broadcastAddr.sin_family = AF_INET;
            broadcastAddr.sin_port = htons(BROADCAST_PORT);
            broadcastAddr.sin_addr.s_addr = htonl(INADDR_BROADCAST);
            
            sendto(broadcastSocket, (char*)&broadcast, sizeof(broadcast), 0,
                  (sockaddr*)&broadcastAddr, sizeof(broadcastAddr));
            
            Sleep(5000); // البث كل 5 ثواني
        }
    }
};

// ==================== فئة عميل الشبكة ====================
class NetworkClient {
private:
    SOCKET serverSocket;
    sockaddr_in serverAddr;
    std::atomic<bool> connected;
    std::atomic<bool> running;
    std::thread receiveThread;
    
    DWORD localPlayerID;
    char playerName[32];
    
public:
    NetworkClient(DWORD playerID, const char* name) 
        : serverSocket(INVALID_SOCKET), connected(false), running(false),
          localPlayerID(playerID) {
        
        strncpy_s(playerName, name, 31);
    }
    
    ~NetworkClient() {
        Disconnect();
    }
    
    bool Connect(const char* serverIP, WORD port = NETWORK_PORT) {
        if (connected) return true;
        
        // تهيئة Winsock
        WSADATA wsaData;
        if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
            printf("WSAStartup failed\n");
            return false;
        }
        
        // إنشاء المقبس
        serverSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (serverSocket == INVALID_SOCKET) {
            printf("Failed to create client socket\n");
            return false;
        }
        
        // إعداد عنوان السيرفر
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_port = htons(port);
        inet_pton(AF_INET, serverIP, &serverAddr.sin_addr);
        
        // الاتصال
        if (connect(serverSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
            printf("Failed to connect to server\n");
            closesocket(serverSocket);
            return false;
        }
        
        // إرسال حزمة المصافحة
        HandshakePacket handshake;
        handshake.playerID = localPlayerID;
        strncpy_s(handshake.playerName, playerName, 31);
        handshake.gameVersion = 1;
        handshake.capabilities = 0x00000001; // دعم المواقع الأساسية
        
        send(serverSocket, (char*)&handshake, sizeof(HandshakePacket), 0);
        
        // استقبال تأكيد الاتصال
        NetworkPacket response;
        int bytesReceived = recv(serverSocket, (char*)&response, sizeof(NetworkPacket), 0);
        
        if (bytesReceived == sizeof(NetworkPacket) && response.packetType == PACKET_HANDSHAKE) {
            connected = true;
            running = true;
            
            // بدء خيط الاستقبال
            receiveThread = std::thread(&NetworkClient::ReceiveThread, this);
            
            printf("Connected to server %s:%d\n", serverIP, port);
            return true;
        }
        
        printf("Connection rejected by server\n");
        closesocket(serverSocket);
        return false;
    }
    
    void Disconnect() {
        connected = false;
        running = false;
        
        if (serverSocket != INVALID_SOCKET) {
            shutdown(serverSocket, SD_BOTH);
            closesocket(serverSocket);
            serverSocket = INVALID_SOCKET;
        }
        
        if (receiveThread.joinable()) {
            receiveThread.join();
        }
        
        WSACleanup();
        printf("Disconnected from server\n");
    }
    
    bool IsConnected() const { 
        return connected; 
    }
    
    void SendPositionUpdate(const PositionPacket& position) {
        if (!connected) return;
        
        NetworkPacket packet;
        packet.packetType = PACKET_POSITION_UPDATE;
        packet.senderID = localPlayerID;
        packet.timestamp = GetTickCount();
        
        memcpy(packet.data, &position, sizeof(PositionPacket));
        
        send(serverSocket, (char*)&packet, sizeof(NetworkPacket), 0);
    }
    
    void SendChatMessage(const char* message) {
        if (!connected) return;
        
        NetworkPacket packet;
        packet.packetType = PACKET_CHAT_MESSAGE;
        packet.senderID = localPlayerID;
        packet.timestamp = GetTickCount();
        
        strncpy_s((char*)packet.data, packet.GetDataSize(), message, packet.GetDataSize() - 1);
        
        send(serverSocket, (char*)&packet, sizeof(NetworkPacket), 0);
    }
    
    std::vector<std::string> DiscoverServers(int timeout = 3000) {
        std::vector<std::string> servers;
        
        SOCKET discoverSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (discoverSocket == INVALID_SOCKET) {
            return servers;
        }
        
        // تعيين خيار البث
        BOOL broadcast = TRUE;
        setsockopt(discoverSocket, SOL_SOCKET, SO_BROADCAST, (char*)&broadcast, sizeof(broadcast));
        
        // تعيين timeout
        setsockopt(discoverSocket, SOL_SOCKET, SO_RCVTIMEO, (char*)&timeout, sizeof(timeout));
        
        // الربط
        sockaddr_in listenAddr;
        listenAddr.sin_family = AF_INET;
        listenAddr.sin_port = htons(BROADCAST_PORT);
        listenAddr.sin_addr.s_addr = htonl(INADDR_ANY);
        
        bind(discoverSocket, (sockaddr*)&listenAddr, sizeof(listenAddr));
        
        // الاستماع للبث
        char buffer[256];
        sockaddr_in fromAddr;
        int fromLen = sizeof(fromAddr);
        
        auto startTime = std::chrono::steady_clock::now();
        
        while (std::chrono::steady_clock::now() - startTime < std::chrono::milliseconds(timeout)) {
            int bytes = recvfrom(discoverSocket, buffer, sizeof(buffer), 0, 
                               (sockaddr*)&fromAddr, &fromLen);
            
            if (bytes > 0) {
                // التحقق من حزمة البث
                struct BroadcastPacket* broadcast = (struct BroadcastPacket*)buffer;
                
                if (broadcast->magic == 0x474E414C) { // "LAN"
                    char serverInfo[256];
                    sprintf_s(serverInfo, sizeof(serverInfo), 
                             "%s (%d/%d) - %s:%d", 
                             broadcast->serverName,
                             broadcast->playerCount,
                             broadcast->maxPlayers,
                             inet_ntoa(fromAddr.sin_addr),
                             broadcast->port);
                    
                    servers.push_back(serverInfo);
                }
            }
        }
        
        closesocket(discoverSocket);
        return servers;
    }
    
private:
    void ReceiveThread() {
        char buffer[MAX_PACKET_SIZE];
        
        while (running && serverSocket != INVALID_SOCKET) {
            fd_set readSet;
            FD_ZERO(&readSet);
            FD_SET(serverSocket, &readSet);
            
            timeval timeout = { 1, 0 };
            
            int result = select(0, &readSet, NULL, NULL, &timeout);
            
            if (result > 0 && FD_ISSET(serverSocket, &readSet)) {
                int bytesReceived = recv(serverSocket, buffer, MAX_PACKET_SIZE, 0);
                
                if (bytesReceived > 0) {
                    ProcessReceivedData(buffer, bytesReceived);
                }
                else if (bytesReceived == 0) {
                    // اتصال مغلق
                    connected = false;
                    break;
                }
                else {
                    // خطأ
                    connected = false;
                    break;
                }
            }
        }
    }
    
    void ProcessReceivedData(const char* data, int size) {
        if (size < (int)sizeof(NetworkPacket)) return;
        
        NetworkPacket* packet = (NetworkPacket*)data;
        
        switch (packet->packetType) {
            case PACKET_POSITION_UPDATE:
                OnPositionUpdate(packet);
                break;
            case PACKET_CHAT_MESSAGE:
                OnChatMessage(packet);
                break;
            case PACKET_PLAYER_JOIN:
                OnPlayerJoin(packet);
                break;
            case PACKET_PLAYER_LEAVE:
                OnPlayerLeave(packet);
                break;
            default:
                break;
        }
    }
    
    void OnPositionUpdate(NetworkPacket* packet) {
        PositionPacket* position = (PositionPacket*)packet->data;
        
        // تحديث موقع اللاعب في الذاكرة
        printf("Position update from player %d\n", packet->senderID);
        
        // هنا سيتم استدعاء دالة تحديث الذاكرة
    }
    
    void OnChatMessage(NetworkPacket* packet) {
        char message[256];
        strncpy_s(message, (char*)packet->data, 255);
        
        printf("Chat from player %d: %s\n", packet->senderID, message);
    }
    
    void OnPlayerJoin(NetworkPacket* packet) {
        char playerName[32];
        strncpy_s(playerName, (char*)packet->data, 31);
        
        printf("Player %s (%d) joined the game\n", playerName, packet->senderID);
    }
    
    void OnPlayerLeave(NetworkPacket* packet) {
        printf("Player %d left the game\n", packet->senderID);
    }
};

// ==================== النظام الرئيسي ====================
class NetworkSystem {
private:
    NetworkServer* server;
    NetworkClient* client;
    std::atomic<bool> isHost;
    
public:
    NetworkSystem() : server(nullptr), client(nullptr), isHost(false) {}
    
    ~NetworkSystem() {
        Shutdown();
    }
    
    bool Initialize(DWORD playerID, const char* playerName, bool hostMode) {
        isHost = hostMode;
        
        if (hostMode) {
            // وضع المضيف
            server = new NetworkServer(playerID, playerName);
            return server->Start();
        }
        else {
            // وضع العميل
            client = new NetworkClient(playerID, playerName);
            return true; // الاتصال لاحقاً
        }
    }
    
    void Shutdown() {
        if (server) {
            server->Stop();
            delete server;
            server = nullptr;
        }
        
        if (client) {
            client->Disconnect();
            delete client;
            client = nullptr;
        }
    }
    
    bool ConnectToServer(const char* serverIP, WORD port = NETWORK_PORT) {
        if (!client) return false;
        return client->Connect(serverIP, port);
    }
    
    void SendPositionUpdate(float x, float y, float z, 
                           float rx, float ry, float rz,
                           BYTE health = 100, BYTE armor = 0) {
        PositionPacket position;
        position.positionX = x;
        position.positionY = y;
        position.positionZ = z;
        position.rotationX = rx;
        position.rotationY = ry;
        position.rotationZ = rz;
        position.health = health;
        position.armor = armor;
        
        if (isHost && server) {
            server->BroadcastPosition(position);
        }
        else if (client && client->IsConnected()) {
            client->SendPositionUpdate(position);
        }
    }
    
    void SendChatMessage(const char* message) {
        if (isHost && server) {
            server->BroadcastChatMessage(message);
        }
        else if (client && client->IsConnected()) {
            client->SendChatMessage(message);
        }
    }
    
    std::vector<std::string> DiscoverLANServers() {
        if (client) {
            return client->DiscoverServers();
        }
        return std::vector<std::string>();
    }
    
    int GetPlayerCount() const {
        if (isHost && server) {
            return server->GetPlayerCount();
        }
        return 0;
    }
    
    bool IsConnected() const {
        if (isHost) return true; // المضيف متصل دائماً
        if (client) return client->IsConnected();
        return false;
    }
};

// ==================== دوال التصدير ====================
static NetworkSystem* g_NetworkSystem = nullptr;

extern "C" __declspec(dllexport) BOOL Network_Initialize(DWORD playerID, const char* playerName, BOOL isHost) {
    if (g_NetworkSystem) return TRUE;
    
    g_NetworkSystem = new NetworkSystem();
    return g_NetworkSystem->Initialize(playerID, playerName, isHost != 0);
}

extern "C" __declspec(dllexport) void Network_Shutdown() {
    if (g_NetworkSystem) {
        g_NetworkSystem->Shutdown();
        delete g_NetworkSystem;
        g_NetworkSystem = nullptr;
    }
}

extern "C" __declspec(dllexport) BOOL Network_Connect(const char* serverIP, WORD port) {
    if (!g_NetworkSystem) return FALSE;
    return g_NetworkSystem->ConnectToServer(serverIP, port);
}

extern "C" __declspec(dllexport) void Network_SendPosition(float x, float y, float z, 
                                                          float rx, float ry, float rz) {
    if (!g_NetworkSystem) return;
    g_NetworkSystem->SendPositionUpdate(x, y, z, rx, ry, rz);
}

extern "C" __declspec(dllexport) void Network_SendChat(const char* message) {
    if (!g_NetworkSystem) return;
    g_NetworkSystem->SendChatMessage(message);
}

extern "C" __declspec(dllexport) int Network_GetPlayerCount() {
    if (!g_NetworkSystem) return 0;
    return g_NetworkSystem->GetPlayerCount();
}

extern "C" __declspec(dllexport) BOOL Network_IsConnected() {
    if (!g_NetworkSystem) return FALSE;
    return g_NetworkSystem->IsConnected();
}