1. BuildUnifiedSystem.bat (اختر 1)
2. تشغيل GTA Vice City
3. تشغيل dist\Launch System.bat
4. اختيار وضع التشغيل (موصى به: Hybrid)
5. اختيار الدور (Host/Client)
6. النظام يعمل تلقائياً!