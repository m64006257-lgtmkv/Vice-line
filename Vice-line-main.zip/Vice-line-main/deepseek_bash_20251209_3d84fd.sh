# شغل ملف البناء
Build_Unified.bat

# اختر الخيار 4 (Create All)