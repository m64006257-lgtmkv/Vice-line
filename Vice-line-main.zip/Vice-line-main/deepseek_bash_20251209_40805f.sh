# الخيار 1: تثبيت عادي
python Unified_Installer.py

# الخيار 2: نسخة محمولة
# انسخ مجلد Portable لأي مكان
# شغل PORTABLE LAUNCHER.bat

# الخيار 3: تشغيل مباشر
python GTAVC_Unified_System.py