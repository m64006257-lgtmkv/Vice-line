// MemoryNetworkCore.cpp - نظام متكامل للذاكرة والشبكة
#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdio.h>
#include <vector>
#include <thread>
#include <atomic>
#include <mutex>
#include <map>
#include <queue>
#include <cmath>

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "wsock32.lib")

// ==================== تعريفات الذاكرة لـ GTA VC ====================
#define VC_BASE_ADDRESS 0x00400000
#define VC_PLAYER_PED_PTR 0x00B7CD98
#define VC_ENTITY_LIST 0x00B74490
#define VC_CAMERA_PTR 0x00B6F028
#define VC_WORLD_PTR 0x00B79594
#define VC_GAME_STATE 0x00B7CB54
#define VC_VEHICLES_ARRAY 0x00B74494
#define VC_PEDS_ARRAY 0x00B74490
#define VC_OBJECTS_ARRAY 0x00B744A0
#define VC_MAX_ENTITIES 400
#define VC_ENTITY_SIZE 408

// هيكل الكائن في الذاكرة
#pragma pack(push, 1)
struct VC_Entity {
    DWORD type;           // 0x00: نوع الكائن (0=فارغ, 1=مشاة, 2=مركبة)
    DWORD handle;         // 0x04: المقبض
    DWORD flags;          // 0x08: الأعلام
    float positionX;      // 0x14: الموقع X
    float positionY;      // 0x18: الموقع Y
    float positionZ;      // 0x1C: الموقع Z
    float rotationX;      // 0x20: الدوران X
    float rotationY;      // 0x24: الدوران Y
    float rotationZ;      // 0x28: الدوران Z
    float velocityX;      // 0x30: السرعة X
    float velocityY;      // 0x34: السرعة Y
    float velocityZ;      // 0x38: السرعة Z
    DWORD modelId;        // 0x50: معرف النموذج
    DWORD playerId;       // 0x5C: معرف اللاعب
    DWORD health;         // 0x540: الصحة
    DWORD armor;          // 0x548: الدروع
    BYTE pedType;         // 0x590: نوع المشاة
    BYTE inVehicle;       // 0x58C: داخل مركبة؟
    DWORD vehiclePtr;     // 0x590: مؤشر المركبة
    DWORD animation;      // 0x5A0: الحركة
    DWORD aiState;        // 0x530: حالة الذكاء الاصطناعي
};
#pragma pack(pop)

// ==================== فئة مدير الذاكرة المتكامل ====================
class MemoryManager {
private:
    HANDLE hProcess;
    DWORD processId;
    DWORD baseAddress;
    std::mutex memoryMutex;
    
    // تتبع الكائنات عن بعد
    std::map<DWORD, DWORD> remoteEntities; // playerID -> entityAddress
    
public:
    MemoryManager() : hProcess(NULL), processId(0), baseAddress(0) {}
    
    ~MemoryManager() {
        Detach();
    }
    
    BOOL AttachToProcess() {
        // البحث عن نافذة GTA VC
        HWND hwnd = FindWindowA(NULL, "GTA: Vice City");
        if (!hwnd) {
            hwnd = FindWindowA(NULL, "Grand Theft Auto: Vice City");
            if (!hwnd) {
                printf("GTA VC window not found\n");
                return FALSE;
            }
        }
        
        // الحصول على معرف العملية
        GetWindowThreadProcessId(hwnd, &processId);
        
        // فتح مقبض العملية
        hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, processId);
        if (!hProcess) {
            printf("Failed to open process %d (Error: %d)\n", processId, GetLastError());
            return FALSE;
        }
        
        // الحصول على عنوان الأساس
        HMODULE modules[1024];
        DWORD needed;
        if (EnumProcessModules(hProcess, modules, sizeof(modules), &needed)) {
            baseAddress = (DWORD)modules[0];
            printf("Attached to GTA VC process %d (Base: 0x%08X)\n", processId, baseAddress);
            return TRUE;
        }
        
        return FALSE;
    }
    
    void Detach() {
        // تنظيف الكائنات عن بعد
        for (auto& pair : remoteEntities) {
            DestroyRemoteEntity(pair.second);
        }
        remoteEntities.clear();
        
        if (hProcess) {
            CloseHandle(hProcess);
            hProcess = NULL;
        }
        
        printf("Detached from GTA VC process\n");
    }
    
    // ==================== قراءة الذاكرة ====================
    BOOL ReadMemory(DWORD address, LPVOID buffer, SIZE_T size) {
        if (!hProcess) return FALSE;
        
        SIZE_T bytesRead;
        return ReadProcessMemory(hProcess, (LPCVOID)address, buffer, size, &bytesRead) && bytesRead == size;
    }
    
    // ==================== كتابة الذاكرة ====================
    BOOL WriteMemory(DWORD address, LPCVOID buffer, SIZE_T size) {
        if (!hProcess) return FALSE;
        
        SIZE_T bytesWritten;
        return WriteProcessMemory(hProcess, (LPVOID)address, buffer, size, &bytesWritten) && bytesWritten == size;
    }
    
    // ==================== قراءة البيانات الأساسية ====================
    BOOL GetLocalPlayerPosition(float& x, float& y, float& z) {
        DWORD playerPtrAddr = baseAddress + VC_PLAYER_PED_PTR;
        DWORD playerPtr;
        
        if (!ReadMemory(playerPtrAddr, &playerPtr, sizeof(DWORD)) || !playerPtr) {
            return FALSE;
        }
        
        return ReadMemory(playerPtr + 0x14, &x, sizeof(float)) &&
               ReadMemory(playerPtr + 0x18, &y, sizeof(float)) &&
               ReadMemory(playerPtr + 0x1C, &z, sizeof(float));
    }
    
    BOOL GetLocalPlayerRotation(float& rx, float& ry, float& rz) {
        DWORD playerPtrAddr = baseAddress + VC_PLAYER_PED_PTR;
        DWORD playerPtr;
        
        if (!ReadMemory(playerPtrAddr, &playerPtr, sizeof(DWORD)) || !playerPtr) {
            return FALSE;
        }
        
        return ReadMemory(playerPtr + 0x20, &rx, sizeof(float)) &&
               ReadMemory(playerPtr + 0x24, &ry, sizeof(float)) &&
               ReadMemory(playerPtr + 0x28, &rz, sizeof(float));
    }
    
    BOOL GetLocalPlayerHealth(DWORD& health) {
        DWORD playerPtrAddr = baseAddress + VC_PLAYER_PED_PTR;
        DWORD playerPtr;
        
        if (!ReadMemory(playerPtrAddr, &playerPtr, sizeof(DWORD)) || !playerPtr) {
            return FALSE;
        }
        
        return ReadMemory(playerPtr + 0x540, &health, sizeof(DWORD));
    }
    
    BOOL GetLocalPlayerArmor(DWORD& armor) {
        DWORD playerPtrAddr = baseAddress + VC_PLAYER_PED_PTR;
        DWORD playerPtr;
        
        if (!ReadMemory(playerPtrAddr, &playerPtr, sizeof(DWORD)) || !playerPtr) {
            return FALSE;
        }
        
        return ReadMemory(playerPtr + 0x548, &armor, sizeof(DWORD));
    }
    
    // ==================== إدارة الكائنات عن بعد ====================
    DWORD FindFreeEntitySlot() {
        DWORD entityList = baseAddress + VC_ENTITY_LIST;
        
        for (DWORD i = 0; i < VC_MAX_ENTITIES; i++) {
            DWORD entityAddr = entityList + (i * VC_ENTITY_SIZE);
            VC_Entity entity;
            
            if (ReadMemory(entityAddr, &entity, sizeof(DWORD))) {
                if (entity.type == 0) { // فتحة فارغة
                    return entityAddr;
                }
            }
        }
        
        return 0;
    }
    
    DWORD CreateRemotePlayer(DWORD playerID, const char* playerName, 
                            float x, float y, float z) {
        std::lock_guard<std::mutex> lock(memoryMutex);
        
        DWORD entityAddr = FindFreeEntitySlot();
        if (!entityAddr) {
            printf("No free entity slots available\n");
            return 0;
        }
        
        // إنشاء كائن مشاة جديد
        VC_Entity entity = {0};
        entity.type = 1; // نوع: مشاة
        entity.playerId = playerID;
        entity.positionX = x;
        entity.positionY = y;
        entity.positionZ = z;
        entity.rotationX = 0.0f;
        entity.rotationY = 0.0f;
        entity.rotationZ = 0.0f;
        entity.health = 100;
        entity.armor = 0;
        entity.pedType = 6; // مدني
        entity.aiState = 0; // تعطيل الذكاء الاصطناعي
        
        if (WriteMemory(entityAddr, &entity, sizeof(VC_Entity))) {
            remoteEntities[playerID] = entityAddr;
            printf("Created remote player %s (ID: %d) at 0x%08X\n", 
                   playerName, playerID, entityAddr);
            return entityAddr;
        }
        
        return 0;
    }
    
    BOOL UpdateRemotePlayer(DWORD playerID, float x, float y, float z,
                           float rx, float ry, float rz, DWORD health, DWORD armor) {
        std::lock_guard<std::mutex> lock(memoryMutex);
        
        auto it = remoteEntities.find(playerID);
        if (it == remoteEntities.end()) {
            return FALSE;
        }
        
        DWORD entityAddr = it->second;
        
        // تحديث الموقع
        BOOL success = TRUE;
        success &= WriteMemory(entityAddr + 0x14, &x, sizeof(float));
        success &= WriteMemory(entityAddr + 0x18, &y, sizeof(float));
        success &= WriteMemory(entityAddr + 0x1C, &z, sizeof(float));
        
        // تحديث الدوران
        success &= WriteMemory(entityAddr + 0x20, &rx, sizeof(float));
        success &= WriteMemory(entityAddr + 0x24, &ry, sizeof(float));
        success &= WriteMemory(entityAddr + 0x28, &rz, sizeof(float));
        
        // تحديث الصحة والدروع
        success &= WriteMemory(entityAddr + 0x540, &health, sizeof(DWORD));
        success &= WriteMemory(entityAddr + 0x548, &armor, sizeof(DWORD));
        
        return success;
    }
    
    void DestroyRemotePlayer(DWORD playerID) {
        std::lock_guard<std::mutex> lock(memoryMutex);
        
        auto it = remoteEntities.find(playerID);
        if (it != remoteEntities.end()) {
            DWORD zero = 0;
            WriteMemory(it->second, &zero, sizeof(DWORD)); // إعادة النوع إلى 0
            
            remoteEntities.erase(it);
            printf("Destroyed remote player %d\n", playerID);
        }
    }
    
    BOOL IsAttached() const {
        return hProcess != NULL;
    }
    
    size_t GetRemotePlayerCount() const {
        return remoteEntities.size();
    }
};

// ==================== نظام الشبكة المبسط ====================
class NetworkSystem {
private:
    SOCKET serverSocket;
    SOCKET clientSocket;
    std::atomic<bool> running;
    std::thread networkThread;
    MemoryManager* memoryManager;
    
    DWORD localPlayerID;
    std::string localPlayerName;
    bool isHost;
    
    // إعدادات الشبكة
    int port;
    int broadcastPort;
    
public:
    NetworkSystem(MemoryManager* memMgr) 
        : serverSocket(INVALID_SOCKET), clientSocket(INVALID_SOCKET),
          running(false), memoryManager(memMgr), localPlayerID(0),
          isHost(false), port(5192), broadcastPort(9999) {}
    
    ~NetworkSystem() {
        Stop();
    }
    
    BOOL Initialize(DWORD playerID, const char* playerName, BOOL hostMode) {
        localPlayerID = playerID;
        localPlayerName = playerName;
        isHost = hostMode;
        
        // تهيئة Winsock
        WSADATA wsaData;
        if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
            printf("WSAStartup failed\n");
            return FALSE;
        }
        
        if (isHost) {
            return StartServer();
        } else {
            return StartClient();
        }
    }
    
    void Stop() {
        running = false;
        
        if (serverSocket != INVALID_SOCKET) {
            closesocket(serverSocket);
            serverSocket = INVALID_SOCKET;
        }
        
        if (clientSocket != INVALID_SOCKET) {
            closesocket(clientSocket);
            clientSocket = INVALID_SOCKET;
        }
        
        if (networkThread.joinable()) {
            networkThread.join();
        }
        
        WSACleanup();
        printf("Network system stopped\n");
    }
    
    BOOL StartServer() {
        serverSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (serverSocket == INVALID_SOCKET) {
            printf("Failed to create server socket\n");
            return FALSE;
        }
        
        sockaddr_in serverAddr;
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_port = htons(port);
        serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);
        
        if (bind(serverSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
            printf("Failed to bind server socket\n");
            closesocket(serverSocket);
            return FALSE;
        }
        
        // تمكين البث
        BOOL broadcast = TRUE;
        setsockopt(serverSocket, SOL_SOCKET, SO_BROADCAST, (char*)&broadcast, sizeof(broadcast));
        
        printf("Server started on port %d\n", port);
        
        running = true;
        networkThread = std::thread(&NetworkSystem::ServerLoop, this);
        
        return TRUE;
    }
    
    BOOL StartClient() {
        clientSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (clientSocket == INVALID_SOCKET) {
            printf("Failed to create client socket\n");
            return FALSE;
        }
        
        // تمكين البث
        BOOL broadcast = TRUE;
        setsockopt(clientSocket, SOL_SOCKET, SO_BROADCAST, (char*)&broadcast, sizeof(broadcast));
        
        printf("Client network ready\n");
        
        running = true;
        networkThread = std::thread(&NetworkSystem::ClientLoop, this);
        
        return TRUE;
    }
    
    void ServerLoop() {
        char buffer[1024];
        sockaddr_in clientAddr;
        int addrLen = sizeof(clientAddr);
        
        while (running) {
            // استقبال الحزم
            int bytesReceived = recvfrom(serverSocket, buffer, sizeof(buffer), 0,
                                        (sockaddr*)&clientAddr, &addrLen);
            
            if (bytesReceived > 0) {
                ProcessPacket(buffer, bytesReceived, clientAddr);
            }
            
            // إرسال بيانات اللاعب المحلي
            SendLocalPlayerData();
            
            Sleep(50); // 20Hz
        }
    }
    
    void ClientLoop() {
        char buffer[1024];
        sockaddr_in serverAddr;
        int addrLen = sizeof(serverAddr);
        
        // اكتشاف السيرفرات أولاً
        DiscoverServers();
        
        while (running) {
            // استقبال الحزم
            int bytesReceived = recvfrom(clientSocket, buffer, sizeof(buffer), 0,
                                        (sockaddr*)&serverAddr, &addrLen);
            
            if (bytesReceived > 0) {
                ProcessPacket(buffer, bytesReceived, serverAddr);
            }
            
            // إرسال بيانات اللاعب المحلي
            SendLocalPlayerData();
            
            Sleep(50); // 20Hz
        }
    }
    
    void DiscoverServers() {
        // بث طلب اكتشاف السيرفرات
        char broadcastMsg[] = "GTALAN_DISCOVER";
        sockaddr_in broadcastAddr;
        
        broadcastAddr.sin_family = AF_INET;
        broadcastAddr.sin_port = htons(broadcastPort);
        broadcastAddr.sin_addr.s_addr = htonl(INADDR_BROADCAST);
        
        sendto(clientSocket, broadcastMsg, sizeof(broadcastMsg), 0,
              (sockaddr*)&broadcastAddr, sizeof(broadcastAddr));
        
        printf("Discovering LAN servers...\n");
    }
    
    void ProcessPacket(char* buffer, int size, sockaddr_in& fromAddr) {
        // تحليل نوع الحزمة
        if (size < 4) return;
        
        DWORD packetType = *(DWORD*)buffer;
        
        switch (packetType) {
            case 1: // حزمة اتصال
                HandleConnectPacket(buffer + 4, size - 4, fromAddr);
                break;
                
            case 2: // حزمة موقع
                HandlePositionPacket(buffer + 4, size - 4, fromAddr);
                break;
                
            case 3: // حزمة مغادرة
                HandleLeavePacket(buffer + 4, size - 4, fromAddr);
                break;
        }
    }
    
    void HandleConnectPacket(char* data, int size, sockaddr_in& fromAddr) {
        if (size < sizeof(DWORD) + 32) return;
        
        DWORD playerID = *(DWORD*)data;
        char playerName[32];
        strncpy_s(playerName, data + 4, 31);
        
        printf("Player %s (%d) connected from %s\n", 
               playerName, playerID, inet_ntoa(fromAddr.sin_addr));
        
        // إنشاء لاعب عن بعد في الذاكرة
        if (memoryManager && memoryManager->IsAttached()) {
            // استخدام موقع افتراضي مؤقت
            memoryManager->CreateRemotePlayer(playerID, playerName, 100.0f, 200.0f, 10.0f);
        }
    }
    
    void HandlePositionPacket(char* data, int size, sockaddr_in& fromAddr) {
        if (size < sizeof(DWORD) + 6 * sizeof(float)) return;
        
        DWORD playerID = *(DWORD*)data;
        float* positionData = (float*)(data + 4);
        
        float x = positionData[0];
        float y = positionData[1];
        float z = positionData[2];
        float rx = positionData[3];
        float ry = positionData[4];
        float rz = positionData[5];
        
        DWORD health = 100, armor = 0;
        if (size >= sizeof(DWORD) + 8 * sizeof(float)) {
            health = (DWORD)positionData[6];
            armor = (DWORD)positionData[7];
        }
        
        // تحديث موقع اللاعب في الذاكرة
        if (memoryManager && memoryManager->IsAttached()) {
            memoryManager->UpdateRemotePlayer(playerID, x, y, z, rx, ry, rz, health, armor);
        }
    }
    
    void HandleLeavePacket(char* data, int size, sockaddr_in& fromAddr) {
        if (size < sizeof(DWORD)) return;
        
        DWORD playerID = *(DWORD*)data;
        
        printf("Player %d disconnected\n", playerID);
        
        // إزالة اللاعب من الذاكرة
        if (memoryManager && memoryManager->IsAttached()) {
            memoryManager->DestroyRemotePlayer(playerID);
        }
    }
    
    void SendLocalPlayerData() {
        if (!memoryManager || !memoryManager->IsAttached()) {
            return;
        }
        
        // قراءة بيانات اللاعب المحلي
        float x, y, z, rx, ry, rz;
        DWORD health, armor;
        
        if (!memoryManager->GetLocalPlayerPosition(x, y, z)) return;
        memoryManager->GetLocalPlayerRotation(rx, ry, rz); // قد يفشل
        memoryManager->GetLocalPlayerHealth(health);
        memoryManager->GetLocalPlayerArmor(armor);
        
        // تجهيز حزمة الموقع
        char buffer[1024];
        DWORD* packetType = (DWORD*)buffer;
        *packetType = 2; // نوع: حزمة موقع
        
        DWORD* playerID = (DWORD*)(buffer + 4);
        *playerID = localPlayerID;
        
        float* positionData = (float*)(buffer + 8);
        positionData[0] = x;
        positionData[1] = y;
        positionData[2] = z;
        positionData[3] = rx;
        positionData[4] = ry;
        positionData[5] = rz;
        positionData[6] = (float)health;
        positionData[7] = (float)armor;
        
        int packetSize = 8 + 8 * sizeof(float); // 4+4 + 8*4 = 40 بايت
        
        // الإرسال
        if (isHost && serverSocket != INVALID_SOCKET) {
            // السيرفر يبث للجميع (هنا يمكن حفظ قائمة العملاء)
            sockaddr_in broadcastAddr;
            broadcastAddr.sin_family = AF_INET;
            broadcastAddr.sin_port = htons(port);
            broadcastAddr.sin_addr.s_addr = htonl(INADDR_BROADCAST);
            
            sendto(serverSocket, buffer, packetSize, 0,
                  (sockaddr*)&broadcastAddr, sizeof(broadcastAddr));
        }
        else if (!isHost && clientSocket != INVALID_SOCKET) {
            // العميل يرسل للسيرفر (يجب معرفة عنوان السيرفر أولاً)
            // هذا يتطلب اكتشاف السيرفرات أو الاتصال المباشر
        }
    }
    
    BOOL ConnectToServer(const char* serverIP, int port = 5192) {
        if (isHost) return TRUE; // السيرفر لا يحتاج للاتصال
        
        // إرسال حزمة اتصال
        char buffer[1024];
        DWORD* packetType = (DWORD*)buffer;
        *packetType = 1; // نوع: حزمة اتصال
        
        DWORD* playerID = (DWORD*)(buffer + 4);
        *playerID = localPlayerID;
        
        char* playerName = buffer + 8;
        strncpy_s(playerName, 32, localPlayerName.c_str(), 31);
        
        int packetSize = 8 + 32;
        
        sockaddr_in serverAddr;
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_port = htons(port);
        inet_pton(AF_INET, serverIP, &serverAddr.sin_addr);
        
        if (sendto(clientSocket, buffer, packetSize, 0,
                  (sockaddr*)&serverAddr, sizeof(serverAddr)) > 0) {
            printf("Connected to server %s:%d\n", serverIP, port);
            return TRUE;
        }
        
        return FALSE;
    }
    
    BOOL IsRunning() const {
        return running;
    }
};

// ==================== المتغيرات العالمية ====================
static MemoryManager* g_MemoryManager = NULL;
static NetworkSystem* g_NetworkSystem = NULL;

// ==================== دوال التصدير ====================
extern "C" __declspec(dllexport) BOOL Memory_Initialize() {
    if (g_MemoryManager) return TRUE;
    
    g_MemoryManager = new MemoryManager();
    return g_MemoryManager->AttachToProcess();
}

extern "C" __declspec(dllexport) void Memory_Shutdown() {
    if (g_MemoryManager) {
        g_MemoryManager->Detach();
        delete g_MemoryManager;
        g_MemoryManager = NULL;
    }
}

extern "C" __declspec(dllexport) BOOL Memory_ReadPosition(float* x, float* y, float* z) {
    if (!g_MemoryManager) return FALSE;
    return g_MemoryManager->GetLocalPlayerPosition(*x, *y, *z);
}

extern "C" __declspec(dllexport) BOOL Memory_ReadRotation(float* rx, float* ry, float* rz) {
    if (!g_MemoryManager) return FALSE;
    return g_MemoryManager->GetLocalPlayerRotation(*rx, *ry, *rz);
}

extern "C" __declspec(dllexport) BOOL Memory_ReadHealth(DWORD* health) {
    if (!g_MemoryManager) return FALSE;
    return g_MemoryManager->GetLocalPlayerHealth(*health);
}

extern "C" __declspec(dllexport) BOOL Memory_ReadArmor(DWORD* armor) {
    if (!g_MemoryManager) return FALSE;
    return g_MemoryManager->GetLocalPlayerArmor(*armor);
}

extern "C" __declspec(dllexport) BOOL Network_Initialize(DWORD playerID, const char* playerName, BOOL isHost) {
    if (!g_MemoryManager && !Memory_Initialize()) {
        printf("Failed to initialize memory manager\n");
        return FALSE;
    }
    
    if (g_NetworkSystem) {
        g_NetworkSystem->Stop();
        delete g_NetworkSystem;
    }
    
    g_NetworkSystem = new NetworkSystem(g_MemoryManager);
    return g_NetworkSystem->Initialize(playerID, playerName, isHost);
}

extern "C" __declspec(dllexport) void Network_Shutdown() {
    if (g_NetworkSystem) {
        g_NetworkSystem->Stop();
        delete g_NetworkSystem;
        g_NetworkSystem = NULL;
    }
}

extern "C" __declspec(dllexport) BOOL Network_Connect(const char* serverIP, int port) {
    if (!g_NetworkSystem) return FALSE;
    return g_NetworkSystem->ConnectToServer(serverIP, port);
}

extern "C" __declspec(dllexport) BOOL Network_IsRunning() {
    if (!g_NetworkSystem) return FALSE;
    return g_NetworkSystem->IsRunning();
}

extern "C" __declspec(dllexport) BOOL Memory_IsAttached() {
    if (!g_MemoryManager) return FALSE;
    return g_MemoryManager->IsAttached();
}

extern "C" __declspec(dllexport) DWORD Memory_GetRemotePlayerCount() {
    if (!g_MemoryManager) return 0;
    return (DWORD)g_MemoryManager->GetRemotePlayerCount();
}

// ==================== نقطة دخول DLL ====================
BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID lpReserved) {
    switch (reason) {
        case DLL_PROCESS_ATTACH:
            // لا نقوم بالتهيئة التلقائية
            break;
            
        case DLL_PROCESS_DETACH:
            Network_Shutdown();
            Memory_Shutdown();
            break;
            
        case DLL_THREAD_ATTACH:
        case DLL_THREAD_DETACH:
            break;
    }
    return TRUE;
}