# 1. تأكد من تشغيل GTA Vice City

# 2. شغل النظام
Run_Integrated.bat

# 3. اتبع التعليمات:
#    - اختر وضع التشغيل (Single/Host/Client)
#    - أدخل اسم اللاعب
#    - إذا اخترت Client، اكتشف السيرفرات أو أدخل IP يدوياً