# 1. قم بحفظ الملفات الثلاثة:
#    - MemoryNetworkCore.cpp
#    - Build_Integrated.bat
#    - IntegratedSystem.py

# 2. شغل ملف البناء
Build_Integrated.bat

# 3. انتقل لمجلد dist
cd dist