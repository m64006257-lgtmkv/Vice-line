# IntegratedSystem.py - النظام المتكامل النهائي
import os
import sys
import time
import ctypes
import threading
from ctypes import wintypes
import json
from enum import Enum
from typing import Tuple, List, Dict, Optional

# ==================== تهيئة النظام ====================
def check_system():
    """فحص متطلبات النظام"""
    if sys.platform != "win32":
        print("❌ يتطلب النظام Windows")
        return False
    
    if sys.version_info < (3, 8):
        print(f"❌ يتطلب Python 3.8+ (لديك {sys.version_info.major}.{sys.version_info.minor})")
        return False
    
    try:
        import psutil
    except ImportError:
        print("⚠ تنبيه: مكتبة psutil غير مثبتة")
        print("   قم بتشغيل: pip install psutil")
    
    return True

# ==================== تحميل DLL المتكامل ====================
class IntegratedCore:
    """واجهة للـ DLL المتكامل"""
    
    def __init__(self):
        self.dll_path = "MemoryNetworkCore.dll"
        self.dll = None
        self.loaded = False
        
        # دوال الذاكرة
        self.Memory_Initialize = None
        self.Memory_Shutdown = None
        self.Memory_ReadPosition = None
        self.Memory_ReadRotation = None
        self.Memory_ReadHealth = None
        self.Memory_ReadArmor = None
        self.Memory_IsAttached = None
        self.Memory_GetRemotePlayerCount = None
        
        # دوال الشبكة
        self.Network_Initialize = None
        self.Network_Shutdown = None
        self.Network_Connect = None
        self.Network_IsRunning = None
        
    def load(self):
        """تحميل DLL"""
        try:
            # البحث عن DLL
            possible_paths = [
                self.dll_path,
                os.path.join(os.getcwd(), self.dll_path),
                os.path.join(os.getcwd(), "system", self.dll_path),
                "MultiplayerCore.dll",
                os.path.join(os.getcwd(), "MultiplayerCore.dll")
            ]
            
            dll_found = None
            for path in possible_paths:
                if os.path.exists(path):
                    dll_found = path
                    break
            
            if not dll_found:
                print(f"❌ لم يتم العثور على {self.dll_path}")
                return False
            
            # تحميل DLL
            self.dll = ctypes.WinDLL(dll_found)
            print(f"✅ تم تحميل DLL: {os.path.basename(dll_found)}")
            
            # تعريف دوال الذاكرة
            self.Memory_Initialize = self.dll.Memory_Initialize
            self.Memory_Initialize.restype = wintypes.BOOL
            
            self.Memory_Shutdown = self.dll.Memory_Shutdown
            
            self.Memory_ReadPosition = self.dll.Memory_ReadPosition
            self.Memory_ReadPosition.argtypes = [
                ctypes.POINTER(ctypes.c_float),
                ctypes.POINTER(ctypes.c_float),
                ctypes.POINTER(ctypes.c_float)
            ]
            self.Memory_ReadPosition.restype = wintypes.BOOL
            
            self.Memory_ReadRotation = self.dll.Memory_ReadRotation
            self.Memory_ReadRotation.argtypes = [
                ctypes.POINTER(ctypes.c_float),
                ctypes.POINTER(ctypes.c_float),
                ctypes.POINTER(ctypes.c_float)
            ]
            self.Memory_ReadRotation.restype = wintypes.BOOL
            
            self.Memory_ReadHealth = self.dll.Memory_ReadHealth
            self.Memory_ReadHealth.argtypes = [ctypes.POINTER(wintypes.DWORD)]
            self.Memory_ReadHealth.restype = wintypes.BOOL
            
            self.Memory_ReadArmor = self.dll.Memory_ReadArmor
            self.Memory_ReadArmor.argtypes = [ctypes.POINTER(wintypes.DWORD)]
            self.Memory_ReadArmor.restype = wintypes.BOOL
            
            self.Memory_IsAttached = self.dll.Memory_IsAttached
            self.Memory_IsAttached.restype = wintypes.BOOL
            
            self.Memory_GetRemotePlayerCount = self.dll.Memory_GetRemotePlayerCount
            self.Memory_GetRemotePlayerCount.restype = wintypes.DWORD
            
            # تعريف دوال الشبكة
            self.Network_Initialize = self.dll.Network_Initialize
            self.Network_Initialize.argtypes = [
                wintypes.DWORD,
                ctypes.c_char_p,
                wintypes.BOOL
            ]
            self.Network_Initialize.restype = wintypes.BOOL
            
            self.Network_Shutdown = self.dll.Network_Shutdown
            
            self.Network_Connect = self.dll.Network_Connect
            self.Network_Connect.argtypes = [ctypes.c_char_p, ctypes.c_int]
            self.Network_Connect.restype = wintypes.BOOL
            
            self.Network_IsRunning = self.dll.Network_IsRunning
            self.Network_IsRunning.restype = wintypes.BOOL
            
            self.loaded = True
            return True
            
        except Exception as e:
            print(f"❌ فشل تحميل DLL: {e}")
            return False
    
    def initialize_memory(self):
        """تهيئة نظام الذاكرة"""
        if not self.loaded:
            return False
        
        print("🔧 تهيئة نظام الذاكرة...")
        if self.Memory_Initialize():
            print("✅ تم تهيئة نظام الذاكرة")
            return True
        
        print("❌ فشل تهيئة نظام الذاكرة")
        return False
    
    def initialize_network(self, player_id, player_name, is_host):
        """تهيئة نظام الشبكة"""
        if not self.loaded:
            return False
        
        print(f"🌐 تهيئة الشبكة ({'Host' if is_host else 'Client'})...")
        
        # تحويل الاسم إلى bytes
        name_bytes = player_name.encode('utf-8')
        
        if self.Network_Initialize(player_id, name_bytes, is_host):
            print("✅ تم تهيئة نظام الشبكة")
            return True
        
        print("❌ فشل تهيئة نظام الشبكة")
        return False
    
    def connect_to_server(self, server_ip, port=5192):
        """الاتصال بالسيرفر"""
        if not self.loaded:
            return False
        
        ip_bytes = server_ip.encode('utf-8')
        return self.Network_Connect(ip_bytes, port)
    
    def read_local_player_data(self):
        """قراءة بيانات اللاعب المحلي"""
        if not self.loaded:
            return None
        
        data = {}
        
        # قراءة الموقع
        x = ctypes.c_float()
        y = ctypes.c_float()
        z = ctypes.c_float()
        
        if self.Memory_ReadPosition(ctypes.byref(x), ctypes.byref(y), ctypes.byref(z)):
            data['position'] = (x.value, y.value, z.value)
        
        # قراءة الدوران
        rx = ctypes.c_float()
        ry = ctypes.c_float()
        rz = ctypes.c_float()
        
        if self.Memory_ReadRotation(ctypes.byref(rx), ctypes.byref(ry), ctypes.byref(rz)):
            data['rotation'] = (rx.value, ry.value, rz.value)
        
        # قراءة الصحة والدروع
        health = wintypes.DWORD()
        armor = wintypes.DWORD()
        
        if self.Memory_ReadHealth(ctypes.byref(health)):
            data['health'] = health.value
        
        if self.Memory_ReadArmor(ctypes.byref(armor)):
            data['armor'] = armor.value
        
        return data
    
    def is_memory_attached(self):
        """التحقق من اتصال الذاكرة"""
        if not self.loaded:
            return False
        return self.Memory_IsAttached()
    
    def get_remote_player_count(self):
        """الحصول على عدد اللاعبين عن بعد"""
        if not self.loaded:
            return 0
        return self.Memory_GetRemotePlayerCount()
    
    def is_network_running(self):
        """التحقق من تشغيل الشبكة"""
        if not self.loaded:
            return False
        return self.Network_IsRunning()
    
    def shutdown(self):
        """إيقاف النظام"""
        if self.loaded:
            self.Network_Shutdown()
            self.Memory_Shutdown()

# ==================== النظام الرئيسي ====================
class GTAMultiplayerSystem:
    """النظام الرئيسي المتكامل"""
    
    def __init__(self):
        self.core = IntegratedCore()
        self.mode = None  # 'single', 'host', 'client'
        self.running = False
        
        # بيانات اللاعب
        self.local_player_id = os.getpid()
        self.local_player_name = f"Player_{self.local_player_id % 10000}"
        
        # الخيوط
        self.sync_thread = None
        
        # الإعدادات
        self.sync_interval = 0.05  # 20Hz
        self.network_port = 5192
        
        # السجلات
        self.logs = []
    
    def log(self, message):
        """تسجيل رسالة"""
        timestamp = time.strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {message}"
        self.logs.append(log_entry)
        print(log_entry)
        
        # حفظ السجل
        if len(self.logs) > 50:
            self._save_logs()
    
    def _save_logs(self):
        """حفظ السجلات"""
        try:
            with open("system_log.json", "w", encoding="utf-8") as f:
                json.dump({
                    'timestamp': time.time(),
                    'mode': self.mode,
                    'logs': self.logs[-20:]
                }, f, indent=2, ensure_ascii=False)
        except:
            pass
    
    def initialize(self, mode='single', player_name=None):
        """تهيئة النظام"""
        self.log(f"🚀 بدء النظام (الوضع: {mode})")
        
        # تحميل DLL
        if not self.core.load():
            self.log("❌ فشل تحميل DLL المتكامل")
            return False
        
        # تهيئة الذاكرة
        if not self.core.initialize_memory():
            self.log("❌ فشل تهيئة الذاكرة")
            return False
        
        # تهيئة الشبكة حسب الوضع
        self.mode = mode
        
        if mode == 'host':
            if player_name:
                self.local_player_name = player_name
            
            if not self.core.initialize_network(
                self.local_player_id,
                self.local_player_name,
                True  # is_host
            ):
                self.log("❌ فشل تهيئة الشبكة (Host)")
                return False
            
            self.log(f"🎮 أنت الآن المضيف: {self.local_player_name}")
            
        elif mode == 'client':
            if player_name:
                self.local_player_name = player_name
            
            if not self.core.initialize_network(
                self.local_player_id,
                self.local_player_name,
                False  # is_host
            ):
                self.log("❌ فشل تهيئة الشبكة (Client)")
                return False
            
            self.log(f"🔗 أنت الآن عميل: {self.local_player_name}")
            
        elif mode == 'single':
            self.log("🎮 وضع اللاعب الواحد")
        
        else:
            self.log("❌ وضع غير معروف")
            return False
        
        # بدء خيط المزامنة
        self.running = True
        self.sync_thread = threading.Thread(target=self._sync_loop, daemon=True)
        self.sync_thread.start()
        
        self.log("✅ تم تهيئة النظام بنجاح")
        return True
    
    def connect_to_server(self, server_ip, port=5192):
        """الاتصال بسيرفر"""
        if self.mode != 'client':
            self.log("❌ يجب أن تكون في وضع Client للاتصال")
            return False
        
        self.log(f"🔗 محاولة الاتصال بـ {server_ip}:{port}...")
        
        if self.core.connect_to_server(server_ip, port):
            self.log("✅ تم الاتصال بالسيرفر")
            return True
        
        self.log("❌ فشل الاتصال بالسيرفر")
        return False
    
    def _sync_loop(self):
        """حلقة مزامنة البيانات"""
        self.log("🔄 بدء حلقة المزامنة...")
        
        sync_count = 0
        
        while self.running:
            try:
                # قراءة بيانات اللاعب المحلي
                if self.core.is_memory_attached():
                    player_data = self.core.read_local_player_data()
                    
                    if player_data and sync_count % 10 == 0:  # تحديث كل 500ms
                        pos = player_data.get('position', (0, 0, 0))
                        self.log(f"📍 الموقع: ({pos[0]:.1f}, {pos[1]:.1f}, {pos[2]:.1f})")
                
                # عرض عدد اللاعبين عن بعد
                remote_count = self.core.get_remote_player_count()
                if remote_count > 0 and sync_count % 20 == 0:
                    self.log(f"👥 اللاعبون عن بعد: {remote_count}")
                
                # التحقق من حالة الشبكة
                if self.mode in ['host', 'client']:
                    if not self.core.is_network_running():
                        self.log("⚠ فقد الاتصال بالشبكة")
                
                sync_count += 1
                time.sleep(self.sync_interval)
                
            except Exception as e:
                self.log(f"❌ خطأ في المزامنة: {e}")
                time.sleep(1)
    
    def discover_servers(self):
        """اكتشاف خوادم LAN"""
        # هذه الدالة ستستخدم منفذ UDP للبث
        import socket
        
        servers = []
        
        try:
            # إنشاء مقبس للبث
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            sock.settimeout(3.0)
            
            # إرسال طلب اكتشاف
            discovery_msg = b"GTALAN_DISCOVER"
            sock.sendto(discovery_msg, ('255.255.255.255', 9999))
            
            # استقبال الردود
            end_time = time.time() + 3.0
            
            while time.time() < end_time:
                try:
                    data, addr = sock.recvfrom(1024)
                    
                    if data.startswith(b"GTALAN_SERVER"):
                        # تحليل بيانات السيرفر
                        try:
                            server_info = json.loads(data[13:].decode('utf-8'))
                            servers.append({
                                'ip': addr[0],
                                'name': server_info.get('name', 'Unknown'),
                                'players': server_info.get('players', 0)
                            })
                        except:
                            pass
                            
                except socket.timeout:
                    continue
                except:
                    break
            
            sock.close()
            
        except Exception as e:
            self.log(f"خطأ في اكتشاف السيرفرات: {e}")
        
        return servers
    
    def get_system_info(self):
        """الحصول على معلومات النظام"""
        return {
            'mode': self.mode,
            'player_id': self.local_player_id,
            'player_name': self.local_player_name,
            'memory_attached': self.core.is_memory_attached(),
            'network_running': self.core.is_network_running(),
            'remote_players': self.core.get_remote_player_count(),
            'running': self.running
        }
    
    def shutdown(self):
        """إيقاف النظام"""
        self.log("🛑 إيقاف النظام...")
        
        self.running = False
        
        # انتظار خيط المزامنة
        if self.sync_thread and self.sync_thread.is_alive():
            self.sync_thread.join(timeout=2)
        
        # إيقاف النظام الأساسي
        self.core.shutdown()
        
        self._save_logs()
        self.log("✅ تم إيقاف النظام")

# ==================== الواجهة الرئيسية ====================
def main():
    """الواجهة الرئيسية"""
    
    print("=" * 60)
    print("🎮 GTA Vice City - Integrated Multiplayer System")
    print("🔄 الذاكرة ←→ الشبكة ←→ اللعبة")
    print("=" * 60)
    print()
    
    # فحص النظام
    if not check_system():
        input("\nاضغط Enter للخروج...")
        return
    
    # إنشاء النظام
    system = GTAMultiplayerSystem()
    
    # اختيار الوضع
    print("\nاختر وضع التشغيل:")
    print("1. Single Player (لعب فردي)")
    print("2. LAN Host (إنشاء غرفة)")
    print("3. LAN Client (الانضمام لغرفة)")
    print()
    
    choice = input("الاختيار [1-3]: ").strip()
    
    if choice == "1":
        mode = 'single'
    elif choice == "2":
        mode = 'host'
    elif choice == "3":
        mode = 'client'
    else:
        print("❌ اختيار غير صحيح، استخدام Single Player")
        mode = 'single'
    
    # اسم اللاعب
    player_name = input(f"\nاسم اللاعب (افتراضي: {system.local_player_name}): ").strip()
    if not player_name:
        player_name = system.local_player_name
    
    # تهيئة النظام
    if not system.initialize(mode, player_name):
        input("\n❌ فشل تهيئة النظام. اضغط Enter للخروج...")
        return
    
    # إذا كان عميل، اكتشاف السيرفرات
    if mode == 'client':
        print("\n🔍 اكتشاف خوادم LAN...")
        servers = system.discover_servers()
        
        if servers:
            print(f"\n✅ تم العثور على {len(servers)} سيرفر:")
            for i, server in enumerate(servers, 1):
                print(f"{i}. {server['name']} - {server['ip']} ({server['players']} لاعبين)")
            
            try:
                server_choice = int(input("\nاختر سيرفر [رقم]: ")) - 1
                if 0 <= server_choice < len(servers):
                    server_ip = servers[server_choice]['ip']
                    if system.connect_to_server(server_ip):
                        print(f"✅ تم الاتصال بـ {servers[server_choice]['name']}")
                    else:
                        print("❌ فشل الاتصال")
                else:
                    print("❌ اختيار غير صحيح")
            except:
                print("❌ مدخل غير صحيح")
        else:
            print("❌ لم يتم العثور على أي سيرفرات")
            
            # الاتصال يدوياً
            server_ip = input("\nأدخل IP السيرفر يدوياً (أو اترك فارغاً للتخطي): ").strip()
            if server_ip:
                if system.connect_to_server(server_ip):
                    print("✅ تم الاتصال")
                else:
                    print("❌ فشل الاتصال")
    
    print(f"\n✅ النظام جاهز! (الوضع: {mode})")
    print("\nالأوامر المتاحة:")
    print("  info - عرض معلومات النظام")
    print("  players - عرض عدد اللاعبين")
    print("  servers - اكتشاف السيرفرات (للعملاء)")
    print("  exit - الخروج")
    print()
    
    # حلقة الأوامر
    while system.running:
        try:
            cmd = input("> ").strip().lower()
            
            if cmd == "exit":
                break
                
            elif cmd == "info":
                info = system.get_system_info()
                print(f"\nمعلومات النظام:")
                print(f"  الوضع: {info['mode']}")
                print(f"  اللاعب: {info['player_name']} (ID: {info['player_id']})")
                print(f"  الذاكرة: {'✅ متصل' if info['memory_attached'] else '❌ غير متصل'}")
                print(f"  الشبكة: {'✅ نشطة' if info['network_running'] else '❌ غير نشطة'}")
                print(f"  اللاعبون عن بعد: {info['remote_players']}")
                
            elif cmd == "players":
                info = system.get_system_info()
                print(f"\n👥 اللاعبون: أنت + {info['remote_players']} لاعب عن بعد")
                
            elif cmd == "servers" and mode == 'client':
                servers = system.discover_servers()
                if servers:
                    print(f"\nتم العثور على {len(servers)} سيرفر:")
                    for server in servers:
                        print(f"  {server['name']} - {server['ip']}")
                else:
                    print("\n❌ لم يتم العثور على سيرفرات")
                    
            else:
                print("❌ أمر غير معروف")
                
        except KeyboardInterrupt:
            print("\n\n⚠ تم إيقاف النظام بواسطة المستخدم")
            break
        except Exception as e:
            print(f"❌ خطأ: {e}")
    
    # إيقاف النظام
    system.shutdown()
    print("\n👋 تم الخروج من النظام")

# ==================== التشغيل ====================
if __name__ == "__main__":
    # تشغيل كمسؤول إذا أمكن
    try:
        is_admin = ctypes.windll.shell32.IsUserAnAdmin()
        if not is_admin:
            print("⚠ تحذير: النظام يعمل بدون صلاحيات مسؤول")
            print("   بعض الميزات قد لا تعمل بشكل صحيح\n")
    except:
        pass
    
    main()